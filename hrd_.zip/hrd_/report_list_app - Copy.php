<?php


//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglinput=date('Y-m-d H:i:s');
$tglnow=date('Y-m-d');

//---mysql connect---//
include 'mysql-connector.php';




$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];

include 'ver_page.php';


$database='0';

$date1=$_REQUEST['date1'];if($date1==''){$date1='%';}else{$database='1';}
$date2=$_REQUEST['date2'];if($date2!=''){$database='2';}
$name=$_REQUEST['name'];if($name==''){$name='';}
$input1=$_REQUEST['input1'];if($input1==''){$input1='%';}
$dept=$_REQUEST['dept'];
	if(($dept=='all department')or($dept=='')){$dept='%';};
	if(($dept=='%')or($dept=='')){$deptname='ALL DEPARTMENT';}else{$deptname=$dept;}
//print $deptname.'<br>';

if(isset($_REQUEST['cek'])){$cek=$_REQUEST['cek'];}else{$cek='';}
if($cek!=''){$cek='checked';$ceklist='1';}else{$ceklist='%';}


if(isset($_REQUEST['datecek'])){$datecek=$_REQUEST['datecek'];}else{$datecek='';}
if($datecek==''){$datecek='%';}else{$cek='checked';$ceklist='1';}
//print "ceklist= ".$ceklist."<br>";
//print "datecek= ".$datecek."<br>";
//print "cek= ".$cek."<br>";


print"

<html>

<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:100%;}
	.div1{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:100px;}

	body{border:solid green 0px; padding:10px 0 0 0;}
	table{border:solid red 0px; font-family:calibri; font-size:11pt; width:100%; border-collapse:collapse}
	.table1{border:solid red 0px; font-family:calibri; font-size:11pt; width:0px; border-collapse:collapse}
	td{border:solid grey 1px; text-align:center;}
	.td1{border:solid grey 0px; text-align:center;}

	.hidden1{display:none;}

/*-----media print page------*/
@media print {
	body, page[size=A4] {
		margin: 0 auto;
		box-shadow: 0;
		display :block;
		zoom: 70%;
		}
	#noshow1{
		display:none;
		}
	#noshow2, #noshow3 {
		display:block;
		}
	}

</style>



<body>

<script>
	function input(){
		document.getElementById('date1').readOnly = true;
		document.getElementById('date1').value ='';
		document.getElementById('date2').readOnly = true;
		document.getElementById('date2').value ='';
	}
	function dates(){
		document.getElementById('input1').readOnly = true;
		document.getElementById('input1').value ='';
	}
	function resetter(){
		document.getElementById('date1').value ='';
		document.getElementById('date2').value ='';
		document.getElementById('input1').value ='';
		document.getElementById('name').value ='';
		document.getElementById('dept').value ='all department';
	}
</script>

<div class=div1 id='noshow1'>
<form action='#' method='get' target='_self'>
<table class=table1>

	<input type='hidden' name='ssid' value='$ssid'><input type='hidden' name='vid' value='$vid'>

	<tr style='font-weight:bold;'>
		<td colspan='3' class=td1>Search By Date Range</td>
		<td class=td1>Search By Date input</td>
		<td class=td1>Search By Name</td>
		<td class=td1>Search By Department</td>

	</tr>
	<tr>
		<td class=td1><input type='date' id='date1' name='date1' value=$date1 onclick='dates();'></td>
		<td class=td1>s/d</td>
		<td class=td1><input type='date' id='date2' name='date2' value=$date2></td>
		<td class=td1><input type='date' id='input1' name='input1' value=$input1 onclick='input();'></td>
		<td class=td1><input type='search' id='name' name='name'  placeholder='searching by Name' value=$name></td>
		<td class=td1><select id='dept' name='dept'  placeholder='searching by Department' >
							<option value='$dept' selected>".strtoupper($deptname)."</option>
							<option value='all department'>ALL DEPARTMENT</option>
							<option value='frontoffice'>FRONTOFFICE</option>
							<option value='food&beverage'>FOOD&BEVERAGE</option>
							<option value='food&beverageproduct'>FOOD&BEVERAGEPRODUCT</option>
							<option value='housekeeping'>HOUSEKEEPING</option>
							<option value='humanresourcedevelopment'>HUMANRESOURCEDEVELOPMENT</option>
							<option value='engineering'>ENGINEERING</option>
							<option value='management'>MANAGEMENT</option>
									</select></td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1><input type='submit' value='searching'></td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1><input type='submit' value='reset'  onclick='resetter();'></td>
	</tr>
	<tr>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1>&nbsp&nbsp</td>

		<td class=td1 >Bill Check -><input type=checkbox name='cek' id='cek' $cek><input type=date name='datecek' id='datecek' value='$datecek'></td>
	</tr>
</table>
</form>
";

//print $database;

if($database=='0'){$result = mysqli_query($con, "SELECT * FROM hrd.form_dw where d1 like '".$input1."' and d12 like '".$name."%' and d4 like '1' and d14 like '".$dept."' and d3 not like '0' and d18 like '".$ceklist."' and d19 like '".$datecek."'  order by d0 desc limit 300;");}
if($database=='1'){$result = mysqli_query($con, "SELECT * FROM hrd.form_dw where (d5 like '".$date1."') and d12 like '".$name."%' and d4 like '1' and d14 like '".$dept."' and d3 not like '0' and d18 like '".$ceklist."'  and d19 like '".$datecek."' order by d0 desc;");}
if($database=='2'){$result = mysqli_query($con, "SELECT * FROM hrd.form_dw where (d5 between '".$date1."' and '".$date2."') and d12 like '".$name."%' and d4 like '1' and d14 like '".$dept."' and d3 not like '0' and d18 like '".$ceklist."' and d19 like '".$datecek."'  order by d0 desc;");}


print"

<table>
	<tr><td style='text-align:left;' class=td1><a href='' onclick='window.print()'><b>Print</b><img src='icon/print.gif'></img></a></td></tr>
</table>
</div>


<div>
<table>
	<tr>
		<td class=td1><b>FORM REQUEST FOR DAILY WORKERS OF ".strtoupper($deptname)."</b></td>
	</tr>


";

//print $input1;
	if($input1!='%'){
		print"<tr><td class=td1><b>Request Date of ".date_format((date_create($input1)),'d F Y' )."</b></td></tr>";
			}
//print $date1.'<br>';
//print $date2.'<br>';
	if(($date1!='%')&&($date2!='')){
		print"<tr><td class=td1><b>Date from ".date_format((date_create($date1)),'d F Y' )." to ".date_format((date_create($date2)),'d F Y' )."</b></td></tr>";
			}
	if(($date1!='%')&&($date2=='')){print"<tr><td class=td1><b>Date of ".date_format((date_create($date1)),'d F Y' )."</b></td></tr>";
			}


print"
</table>
<br>
<table>
	<tr>
		<td>NO</td>
		<td style='width:180px;'>DATE</td>
		<td>NAME OF DW</td>
		<td>SALARY</td>
		<td>TOTAL HOURS</td>
		<td>TOTAL</td>
		<td>REMARK</td>
		<td>DEPARTMENT</td>
		<td id='noshow2' class='hidden1'>CHASIER</td>
	</tr>
";

$total='0';
$n='0';
while($row = mysqli_fetch_row($result)){
$n++;

$ganjil=fmod($n+2,2);
	if($ganjil=='1'){$colorbg='#e8e9eb';}else{$colorbg='none';}

print"
	<tr style='background-color:".$colorbg.";'>
		<td rowspan='2'>$n</td>
	";

	if($row[6]=='0000-00-00'){	
	print"	<td>".date_format((date_create($row[5])),'d F Y' )."</td>	";
			}else{print"<td>".date_format((date_create($row[5])),'d F Y' )." s/d ".date_format((date_create($row[6])),'d F Y' )."</td>";}
	print"
		<td rowspan='2'>".strtoupper($row[12])."</td>
		<td rowspan='2'>Rp ".number_format($row[10],0,',','.').",-</td>
		<td rowspan='2'>".$row[13]."</td>
		<td rowspan='2'>Rp ".number_format($row[11],0,',','.').",-</td>
		<td rowspan='2' style=' width:220px; word-wrap: break-word'>".ucfirst(strtolower($row[17]))."</td>
		<td rowspan='2' style='font-size:13px;'>".$row[14]."</td>
		<td class='hidden1' id='noshow3' style='border:0px;'>(&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp)</td>
	</tr>
	";

	if($row[9]!='null'){
				if($row[9]=='A'){$jadwal='15:00 - 23:00';}
				if($row[9]=='A2'){$jadwal='16:00 - 24:00';}
				if($row[9]=='A4'){$jadwal='18:00 - 02:00';}
				if($row[9]=='M'){$jadwal='07:00 - 15:00';}
				if($row[9]=='D1'){$jadwal='09:00 -17:00';}
				if($row[9]=='D2'){$jadwal='10:00 - 18:00';}
				if($row[9]=='SN'){$jadwal='09:00 - 14:00';}
				if($row[9]=='NS'){$jadwal='08:00 - 16:00';}
				if($row[9]=='N'){$jadwal='23:00 - 07:00';}
				if($row[9]=='N2'){$jadwal='23:00 - 02:00';}
				if($row[9]=='D3'){$jadwal='11:00 - 19:00';}
				if($row[9]=='D4'){$jadwal='12:00 - 20:00';}
				if($row[9]=='D5'){$jadwal='13:00 - 21:00';}
				if($row[9]=='D6'){$jadwal='14:00 - 22:00';}
				if($row[9]=='M1'){$jadwal='06:00 - 14:00';}
				if($row[9]=='M2'){$jadwal='07:00 - 15:00';}
				if($row[9]=='EM'){$jadwal='04:00 - 12:00';}
				if($row[9]=='EM2'){$jadwal='03:00 - 11:00';}
		print"
	<tr style='background-color:".$colorbg.";'>
		<td>".$row[9]." (".$jadwal.")</td>
	</tr>
		";

			}else{print "<tr style='background-color:".$colorbg.";'><td>".$row[7]." - ".$row[8]."</td></tr>";}
		$total=$total+strval($row[11]);
}


print"


	<tr>
		<td colspan=5><b>TOTAL BIAYA</b></td>
		<td><b>Rp ".number_format($total,0,',','.').",-</b></td>
	</tr>
</table>

</div>

</body>
</html>
";

mysqli_close($con);
?>