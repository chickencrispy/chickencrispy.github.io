<?php


//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglinput=date('Y-m-d H:i:s');
$tglnow=date('Y-m-d');

//---mysql connect---//
include 'mysql-connector.php';

include 'vercfg.php';

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];

include'ver_page.php';

$date1=$_REQUEST['date1'];
//print $date1.'<br>';

$input1=$_REQUEST['input1'];
//print $input1.'<br>';

$name=$_REQUEST['name'];
//print $name.'<br>';

$database='0';
$dept=$_REQUEST['dept'];
	if(($dept=='all department')or($dept=='')){$dept='%';};
	if(($dept=='%')or($dept=='')){$deptname='ALL DEPARTMENT';}else{$deptname=$dept;}
//print $deptname.'<br>';

print"

<html>

<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:1000px;}
	body{border:solid green 0px; padding:10px 0 0 0;}
	table{border:solid red 0px; font-family:calibri; font-size:11pt; width:100%; border-collapse:collapse}
	.table1{border:solid red 0px; font-family:calibri; font-size:11pt; width:0px; border-collapse:collapse}
	td{border:solid grey 1px; text-align:center;}
	.td1{border:solid grey 0px; text-align:center;}
	a{text-decoration:none; color:#d1382c; font-weight:bold;}

</style>



<body>

<script>
	function resetter(){
		document.getElementById('dept').value ='all department';
		document.getElementById('date1').value ='';
		document.getElementById('input1').value ='';
		document.getElementById('name').value ='';
	}
</script>

<div>
<form action='#' method='get' target='_self'>
<table class=table1>
	<tr style='font-weight:bold;'>
		<td class=td1>Search By Date of DW</td>
		<td class=td1>Search By Input</td>
		<td class=td1>Search By Name</td>
		<td class=td1>Search By Department</td>

	</tr>
	<tr>
		<input type='hidden' value='$ssid' name='ssid'><input type='hidden' value='$vid' name='vid'>

		<td class=td1><input type='date' value='".$date1."' name='date1' id='date1'></td>
		<td class=td1><input type='date' value='".$input1."' name='input1' id='input1'></td>
		<td class=td1><input type='search' value='".$name."' name='name' id='name'></td>
		<td class=td1><select id='dept' name='dept'  placeholder='searching by Department' >
							<option value='$dept' selected>".strtoupper($deptname)."</option>
							<option value='all department'>ALL DEPARTMENT</option>
							<option value='frontoffice'>FRONT OFFICE</option>
							<option value='food&beverage'>FOOD&BEVERAGE</option>
							<option value='housekeeping'>HOUSEKEEPING</option>
							<option value='humanresourcedevelopment'>HUMANRESOURCEDEVELOPMENT</option>
							<option value='engineering'>ENGINEERING</option>
									</select></td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1><input type='submit' value='searching'></td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1><input type='submit' value='reset'  onclick='resetter();'></td>
	</tr>
</table>
</form>
<table>
	<tr>
		<td><b>FORM REQUEST FOR DAILY WORKERS OF ".strtoupper($deptname)."</b></td>
	</tr>
</table>
<br>
<table>
	<tr>
		<td>NO</td>
		<td>DATE</td>
		<td>NAME OF DW</td>
		<td>SALARY</td>
		<td>TOTAL HOURS</td>
		<td>TOTAL</td>
		<td>REMARK</td>
		<td>CANCEL</td>
	</tr>
";

//print $database;

if($database=='0'){	$result = mysqli_query($con, "SELECT * FROM hrd.form_dw where d1 like '".$input1."%' and d5 like '".$date1."%' and d12 like '".$name."%' and d3 not like '0' and d4 like '1' and d14 like '".$dept."%' order by d0 desc limit 200;");}

$n='0';
while($row = mysqli_fetch_row($result)){
$n++;

$ganjil=fmod($n+2,2);
	if($ganjil=='1'){$colorbg='#e8e9eb';}else{$colorbg='none';}

print"
	<tr style='background-color:".$colorbg.";'>
		<td rowspan='2'>$n</td>
	";
	if($row[6]=='0000-00-00'){	
	print"	<td><a href='cg_schedule.php?ssid=$ssid&vid=$vid&page=$row[0]&time1=&time2=&chgsalary=&cgdate=' target='_self''>".date_format((date_create($row[5])),'d F Y' )."</a></td>	";
			}else{print"<td><a href='#'>".date_format((date_create($row[5])),'d F Y' )." s/d ".date_format((date_create($row[6])),'d F Y' )."</a></td>";}
	print"
		<td rowspan='2'><a href='#' onclick='window.location.href=`cg_name.php?ssid=$ssid&vid=$vid&page=$row[0]`' >".strtoupper($row[12])."</a></td>
		<td rowspan='2'>Rp ".number_format($row[10],0,',','.').",-</td>
		<td rowspan='2'>".$row[13]."</td>
		<td rowspan='2'>Rp ".number_format($row[11],0,',','.').",-</td>
		<td rowspan='2' style='word-wrap: break-word; font-size:11pt; '>".strtolower($row[17])."</td>
		<td rowspan='2'><a href='cancel_app.php?ssid=$ssid&vid=$vid&page=$row[0]' target='_self'><img src='icon/cross.gif'></a></td>
	</tr>
	";

	if($row[9]!='null'){
				if($row[9]=='A'){$jadwal='15:00 - 23:00';}
				if($row[9]=='M'){$jadwal='07:00 - 15:00';}
				if($row[9]=='D1'){$jadwal='09:00 -17:00';}
				if($row[9]=='D2'){$jadwal='09:00 - 18:00';}
				if($row[9]=='SN'){$jadwal='09:00 - 14:00';}
				if($row[9]=='NS'){$jadwal='08:00 - 16:00';}
				if($row[9]=='N'){$jadwal='23:00 - 07:00';}
				if($row[9]=='D3'){$jadwal='11:00 - 19:00';}
				if($row[9]=='D4'){$jadwal='12:00 - 20:00';}
				if($row[9]=='D5'){$jadwal='13:00 - 21:00';}
				if($row[9]=='M1'){$jadwal='06:00 - 14:00';}
				if($row[9]=='M2'){$jadwal='07:00 - 15:00';}
				if($row[9]=='D6'){$jadwal='14:00 - 22:00';}
		print"
	<tr style='background-color:".$colorbg.";'>
		<td>".$row[9]." (".$jadwal.")</td>
	</tr>
		";
			}else{print "<tr style='background-color:".$colorbg.";'><td>".$row[7]." - ".$row[8]."</td></tr>";}
}


print"

</table>

</div>

</body>
</html>
";

mysqli_close($con);
?>