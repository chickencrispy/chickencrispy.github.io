<?php
//$date1=date_create("2022-06-27 22:00:00");
//$date2=date_create("2022-06-28 05:00:00");
//$diff=date_diff($date1,$date2);
//echo $diff->format("%a days %H Jam %I Menit")."<br>";



//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d');

//---mysql connect---//
include 'mysql-connector.php';


$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];


include 'ver_page.php';

print"

<html>
<head><meta name='viewport' content='width=device-width, initial-scale=1.0'></head>
<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:100%;}
	body{border:solid green 0px;}
	table{border:solid red 0px; font-family:calibri; font-size:13pt; width:100%; border-collapse:collapse}
	tr,td{border:solid grey 1px; text-align:center;border-collapse:collapse;}
	input{height:25pt;}
	select{height:25pt;}
	.inputa{font-size:13pt;}
	.table1{width:0px; margin:0 0 0 0;}
	button{ border-collapse:collapse; color:black;}
	.button1{border-collapse:collapse; color:black; height:30pt; width:60pt;}
	a{text-decoration:none;}
</style>






<script>
var nroom = 0;
function myFunction() {
	nroom=nroom+1;//alert (nroom);
	var a='<td><input type=text id=name'+nroom+' name=name'+nroom+' class=inputa size=10 required></td>';
	var b='<td ><input type=date id=date1'+nroom+' name=date1'+nroom+' required></td>';
	var c='<td>&nbsp s/d &nbsp</td>';
	var d='<td><input type=date id=date2'+nroom+' name=date2'+nroom+' readonly></td>';
	var e='<td><input type=radio onclick=msg'+nroom+'(); id=radio1'+nroom+' ><input type=radio onclick=del'+nroom+'(); id=radio2'+nroom+' checked></td>';
	var f='<td><input type=time id=time1'+nroom+' name=time1'+nroom+' disabled></td>';
	var g='<td>&nbsp s/d &nbsp</td>';
	var h='<td><input type=time id=time2'+nroom+' name=time2'+nroom+' disabled></td>';
	var i='<td><select id=time3'+nroom+' name=time3'+nroom+'><option value=null>-</option><option value=A>A</option><option value=A2>A2</option><option value=A4>A4</option><option value=M>M</option><option value=D1>D1</option><option value=D2>D2</option><option value=SN>SN</option><option value=NS>NS</option><option value=N>N</option><option value=N2>N2</option><option value=D3>D3</option><option value=D4>D4</option><option value=D5>D5</option><option value=D6>D6</option><option value=M1>M1</option><option value=M2>M2</option><option value=EM>EM</option></select></td>';
	var j='<td><select id=salary'+nroom+' name=salary'+nroom+'><option value=null>-</option><option value=165000>Rp.165.000,-</option><option value=150000>Rp.150.000,-</option><option value=125000>Rp.125.000,-</option><option value=100000>Rp.100.000,-</option><option value=60000>Rp.60.000,-</option><option value=50000>Rp.50.000,-</option></select></td>';
	var k='<td><input type=text name=rmkDW'+nroom+' id=rmkDW'+nroom+' size=10></td>';


  var table = document.getElementById('myTable');
		if(nroom<=9){
  var row = table.insertRow(-1);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);
  var cell4 = row.insertCell(3);
  var cell5 = row.insertCell(4);
  var cell6 = row.insertCell(5);
  var cell7 = row.insertCell(6);
  var cell8 = row.insertCell(7);
  var cell9 = row.insertCell(8);
  var cell10 = row.insertCell(9);
  var cell11 = row.insertCell(10);
  cell1.innerHTML =a;
  cell2.innerHTML =b;
  cell3.innerHTML =c;
  cell4.innerHTML =d;
  cell5.innerHTML =e;
  cell6.innerHTML =f;
  cell7.innerHTML =g;
  cell8.innerHTML =h;
  cell9.innerHTML =i;
  cell10.innerHTML =j;
  cell11.innerHTML =k;
			}else{nroom=nroom-1;alert('can`t more than 10 table');}
		}
function delfunction() {
			if(!nroom<=0){nroom=nroom-1; document.getElementById('myTable').deleteRow(-1);}
		}



	function msg(){
		document.getElementById('time1').disabled = false;
		document.getElementById('time2').disabled = false;
		document.getElementById('time3').disabled = true;
		document.getElementById('salary').disabled = true;

		document.getElementById('radio2').checked=false;
	}
	function msg1(){
		document.getElementById('time11').disabled = false;
		document.getElementById('time21').disabled = false;
		document.getElementById('time31').disabled = true;
		document.getElementById('salary1').disabled = true;

		document.getElementById('radio21').checked=false;
	}
	function msg2(){
		document.getElementById('time12').disabled = false;
		document.getElementById('time22').disabled = false;
		document.getElementById('time32').disabled = true;
		document.getElementById('salary2').disabled = true;

		document.getElementById('radio22').checked=false;
	}
	function msg3(){
		document.getElementById('time13').disabled = false;
		document.getElementById('time23').disabled = false;
		document.getElementById('time33').disabled = true;
		document.getElementById('salary3').disabled = true;

		document.getElementById('radio23').checked=false;
	}
	function msg4(){
		document.getElementById('time14').disabled = false;
		document.getElementById('time24').disabled = false;
		document.getElementById('time34').disabled = true;
		document.getElementById('salary4').disabled = true;

		document.getElementById('radio24').checked=false;
	}
	function msg5(){
		document.getElementById('time15').disabled = false;
		document.getElementById('time25').disabled = false;
		document.getElementById('time35').disabled = true;
		document.getElementById('salary5').disabled = true;

		document.getElementById('radio25').checked=false;
	}
	function msg6(){
		document.getElementById('time16').disabled = false;
		document.getElementById('time26').disabled = false;
		document.getElementById('time36').disabled = true;
		document.getElementById('salary6').disabled = true;

		document.getElementById('radio26').checked=false;
	}
	function msg7(){
		document.getElementById('time17').disabled = false;
		document.getElementById('time27').disabled = false;
		document.getElementById('time37').disabled = true;
		document.getElementById('salary7').disabled = true;

		document.getElementById('radio27').checked=false;
	}
	function msg8(){
		document.getElementById('time18').disabled = false;
		document.getElementById('time28').disabled = false;
		document.getElementById('time38').disabled = true;
		document.getElementById('salary8').disabled = true;

		document.getElementById('radio28').checked=false;
	}
	function msg9(){
		document.getElementById('time19').disabled = false;
		document.getElementById('time29').disabled = false;
		document.getElementById('time39').disabled = true;
		document.getElementById('salary9').disabled = true;

		document.getElementById('radio29').checked=false;
	}
	function del(){
		document.getElementById('time1').disabled = true;
		document.getElementById('time2').disabled = true;
		document.getElementById('time3').disabled = false;
		document.getElementById('salary').disabled = false;
		document.getElementById('radio1').checked=false;
	}
	function del1(){
		document.getElementById('time11').disabled = true;
		document.getElementById('time21').disabled = true;
		document.getElementById('time31').disabled = false;
		document.getElementById('salary1').disabled = false;
		document.getElementById('radio11').checked=false;
	}
	function del2(){
		document.getElementById('time12').disabled = true;
		document.getElementById('time22').disabled = true;
		document.getElementById('time32').disabled = false;
		document.getElementById('salary2').disabled = false;
		document.getElementById('radio12').checked=false;
	}
	function del3(){
		document.getElementById('time13').disabled = true;
		document.getElementById('time23').disabled = true;
		document.getElementById('time33').disabled = false;
		document.getElementById('salary3').disabled = false;
		document.getElementById('radio13').checked=false;
	}
	function del4(){
		document.getElementById('time14').disabled = true;
		document.getElementById('time24').disabled = true;
		document.getElementById('time34').disabled = false;
		document.getElementById('salary4').disabled = false;
		document.getElementById('radio14').checked=false;
	}
	function del5(){
		document.getElementById('time15').disabled = true;
		document.getElementById('time25').disabled = true;
		document.getElementById('time35').disabled = false;
		document.getElementById('salary5').disabled = false;
		document.getElementById('radio15').checked=false;
	}
	function del6(){
		document.getElementById('time16').disabled = true;
		document.getElementById('time26').disabled = true;
		document.getElementById('time36').disabled = false;
		document.getElementById('salary6').disabled = false;
		document.getElementById('radio16').checked=false;
	}
	function del7(){
		document.getElementById('time17').disabled = true;
		document.getElementById('time27').disabled = true;
		document.getElementById('time37').disabled = false;
		document.getElementById('salary7').disabled = false;
		document.getElementById('radio17').checked=false;
	}
	function del8(){
		document.getElementById('time18').disabled = true;
		document.getElementById('time28').disabled = true;
		document.getElementById('time38').disabled = false;
		document.getElementById('salary8').disabled = false;
		document.getElementById('radio18').checked=false;
	}
	function del9(){
		document.getElementById('time19').disabled = true;
		document.getElementById('time29').disabled = true;
		document.getElementById('time39').disabled = false;
		document.getElementById('salary9').disabled = false;
		document.getElementById('radio19').checked=false;
	}


</script>

<script type='text/javascript'>
	window.history.forward();
	function noBack(){window.history.forward();}	
</script>
<body onload='noBack();' onpageshow='if (event.persisted) noBack();' onload=''>
<div>

<table>
	<tr>
		<td style='background-color:#f7f5f5;'><b>REQUEST APP</b></td>
		<td style='width:70px;height:30px; background-color:#f7f5f5;'><b><a href='/hrd'>Logout</a></b></td>
	</tr>
</table>
<br>
<table class='table1'>
	<tr>
		<td><button class=button1 onclick='window.location.assign(`/hrd/main.php?ssid=$ssid&vid=$vid`);'><b>Add</b></button></td>
		<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
		<td><button class=button1 onclick='window.open(`report_list_app.php?ssid=$ssid&vid=$vid&date1=&date2=&input1=&name=&dept=`);'><b>FrmLog</b></button></td>
		<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
		<td><button class=button1 onclick='window.open(`appr_list_app.php?ssid=$ssid&vid=$vid&date1=&date2=&input1=&name=&dept=`);'><b>Approval</b></button></td>
		<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
		<td><button class=button1 onclick='window.open(`report_app.php?ssid=$ssid&vid=$vid&date1=&date2=&input1=&name=&dept=&approvepage=A`);'><b>Report</b></button></td>
		<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
		<td><button class=button1 onclick='window.open(`cne_app.php?ssid=$ssid&vid=$vid&date1=&input1=&name=&dept=`);'><b>C&E</b></button></td>
		<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
		<td><button class=button1 onclick='window.open(`log_app.php?ssid=$ssid&vid=$vid&tiket=`);'><b>Log</b></button></td>
		<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>
		<td><button class=button1 onclick='window.open(`summary_app.php?ssid=$ssid&vid=$vid&tiket=`);'><b>Summary</b></button></td>
		<td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</td>

		<td><button class=button1 onclick='window.open(`Account_app.php?ssid=$ssid&vid=$vid&position=`);'><b>Account</b></button></td>
	</tr>
	
</table>
<br>

<table class='table1'>
	<tr>
		<td><button type='button' onclick='myFunction()'>Add</button></td>
		<td>&nbsp&nbsp&nbsp&nbsp</td>
		<td><button id='myBtn' type='button' onclick='delfunction()'>Del</button></td>
	</tr>
</table>

<form action='temp_dw.php' method='get' target='_blank'>
<input type='hidden' name='ssid' value=$ssid></input>
<input type='hidden' name='vid' value=$vid></input>

	<table id='myTable'>
		<tr style='font-weight:bold;'>	<td>Name</td>
			<td colspan=3>Date of DW</td>
			<td colspan=5>Time Schedule</span></td>
			<td>Salary</td>
			<td>Remark</td>
		</tr>
		<tr>
			<td><input type='text' id='name' name='name' class='inputa' size='10' required></td>
			<td ><input type='date' id='date1' name='date1' required></td>
			<td>&nbsp s/d &nbsp</td>
			<td><input type='date' id='date2' name='date2' readonly></td>
			<td><input type='radio' onclick='msg();' id='radio1' ><input type='radio' onclick='del()' id='radio2' checked></td>
			<td><input type='time' id='time1' name='time1' disabled></td>
			<td>&nbsp s/d &nbsp</td>
			<td><input type='time' id='time2' name='time2' disabled></td>
			<td><select id='time3' name='time3'>
				<option value='null'>-</option>
				<option value='A'>A</option>
				<option value='A2'>A2</option>
				<option value='A4'>A4</option>
				<option value='M'>M</option>
				<option value='D1'>D1</option>
				<option value='D2'>D2</option>
				<option value='SN'>SN</option>
				<option value='NS'>NS</option>
				<option value='N'>N</option>
				<option value='N2'>N2</option>
				<option value='D3'>D3</option>
				<option value='D4'>D4</option>
				<option value='D5'>D5</option>
				<option value=D6>D6</option>
				<option value='M1'>M1</option>
				<option value='M2'>M2</option>
				<option value='EM'>EM</option>
			</select></td>
			<td><select id='salary' name='salary'>
				<option value='165000' selected>Rp.165.000,-</option>
				<option value='150000'>Rp.150.000,-</option>
				<option value='125000'>Rp.125.000,-</option>
				<option value='100000'>Rp.100.000,-</option>
				<option value='60000'>Rp.60.000,-</option>
				<option value='50000'>Rp.50.000,-</option>
			</select></td>
			<td><input type='text' name='rmkDW' id='rmkDW' size='10'></td>
		</tr>
	</table>
<br>
	<table>
		<tr>
			<td style='width:600px;'>&nbsp</td>
			<td >Note :</td>
			<td ><ul>
				<li>A 	: 15:00-23:00</li>
				<li>A2 	: 16:00-24:00</li>
				<li>A4 	: 18:00-02:00</li>
				<li>M 	: 07:00-15:00</li>
				<li>D1 	: 09:00-17:00</li>
				<li>D2 	: 10:00-18:00</li>
				<li>SN 	: 09:00-14:00</li>
				<li>NS 	: 08:00-16:00</li>
				<li>N 	: 23:00-07:00</li>
				<li>N2 	: 23:00-02:00</li>
				<li>D3 	: 11:00-19:00</li>
				<li>D4 	: 12:00-20:00</li>
				<li>D5 	: 13:00-21:00</li>
				<li>D6 	: 14:00-22:00</li>
				<li>M1 	: 06:00-14:00</li>
				<li>M2 	: 07:00-15:00</li>
				<li>EM 	: 04:00-12:00</li>
				<li>Jam 24:00 	= 12:00 AM (malam)</li>
				<li>Jam 12:00 	= 12:00 PM (siang)</li>
			</ul></td>
		</tr>
		<tr>
			<td colspan=4><input type='submit' value='SAVE'></td>
		</tr>
</form>
	</table>

</div>

</body>
</html>
";
?>