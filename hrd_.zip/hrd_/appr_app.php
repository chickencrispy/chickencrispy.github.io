<?php


//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglinput=date('Y-m-d H:i:s');
$tglnow=date('Y-m-d');

//---mysql connect---//
include 'mysql-connector.php';

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];

include 'ver_page.php';

$database='0';
$input1=$_REQUEST['input1'];if($input1==''){$input1=$tglnow;}


$dept=$_REQUEST['dept'];
	if(($dept=='all department')or($dept=='')){$dept='%';};
	if(($dept=='%')or($dept=='')){$deptname='ALL DEPARTMENT';}else{$deptname=$dept;}
//print $deptname.'<br>';
//print $input1.'<br>';


print"

<html>

<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:1000px;}
	body{border:solid green 0px; padding:10px 0 0 0;}
	table{border:solid red 0px; font-family:calibri; font-size:11pt; width:100%; border-collapse:collapse}
	.table1{border:solid red 0px; font-family:calibri; font-size:11pt; width:0px; border-collapse:collapse}
	td{border:solid grey 1px; text-align:center;}
	.td1{border:solid grey 0px; text-align:left;}

</style>

<body>

<script>


	function details(){
 	 	var x = document.getElementById('detail');
  		if (window.getComputedStyle(x).display === 'none') {
    		x.style.display = 'block';
		document.getElementById('fprejected1').disabled =false;
		document.getElementById('fpapproved1').disabled =false;
		document.getElementById('fprejected2').disabled =false;
		document.getElementById('fpapproved2').disabled =false;
		document.getElementById('fprejected3').disabled =false;
		document.getElementById('fpapproved3').disabled =false;
		document.getElementById('fprejected4').disabled =false;
		document.getElementById('fpapproved4').disabled =false;
		document.getElementById('fprejected5').disabled =false;
		document.getElementById('fpapproved5').disabled =false;
  		}
	}
	function undetails(){
 	 	var x = document.getElementById('detail');
  		if (window.getComputedStyle(x).display === 'block') {
     		x.style.display = 'none';
		document.getElementById('fprejected1').disabled =false;
		document.getElementById('fpapproved1').disabled =false;
		document.getElementById('fprejected2').disabled =false;
		document.getElementById('fpapproved2').disabled =false;
		document.getElementById('fprejected3').disabled =false;
		document.getElementById('fpapproved3').disabled =false;
		document.getElementById('fprejected4').disabled =false;
		document.getElementById('fpapproved4').disabled =false;
		document.getElementById('fprejected5').disabled =false;
		document.getElementById('fpapproved5').disabled =false;
  		}
	}

	function resetter(){
		document.getElementById('input1').value ='".$tglnow."';
		document.getElementById('dept').value ='all department';
		}
	function reloader(){
		setTimeout(function(){
			window.location.reload();
		}, 2000);
		}

</script>
";

//print $database.'<br>';

if($database=='0'){$result = mysqli_query($con, "SELECT * FROM hrd.form_dw where d3 like '0' and d4 like '1' and d14 like '".$dept."' and d1 like '".$input1."' order by d0 asc limit 200;");}


//*****************form request******************//
$result1 = mysqli_query($con, "SELECT *, count(d0) as d21, sum(d11) as d22 FROM hrd.form_dw where d3 like '0' and d4 like '1' and d1 like '".$input1."' and d14 like '".$dept."' group by d14;");

//*****************detail******************//
$result2 = mysqli_query($con, "SELECT *, count(d5) as d21 FROM hrd.form_dw where d3 like '0' and d1 like '".$input1."' and d4 like '1' and d14 like '".$dept."' group by d16;");

//print $dept;

//**************last date form info**********************//
$result3 = mysqli_query($con, "SELECT *, count(d16) as d21 FROM hrd.form_dw where d3 like '0' and d4 like '1' and d1 < '".$tglnow."' group by d14;");

print"

<div>
<form action='#' method='get' target='_self'>
<table>

";

$t='0';
while($row3 = mysqli_fetch_row($result3)){

if(($row3[0]!='')&&($t=='0')){print "<tr><td style='text-align:left;' class=td1><b><i><u>Last Date Form</u></i></b></td></tr>"; $t++;}
	
print"
<tr><td style='text-align:left; color:#f70c0c; font-size:12pt;' class=td1><i>On date of <b>".date_format((date_create($row3[1])),'d F Y' )." Dept. $row3[14]</b> request form </i></td></tr>
";

}

print"
</table>
<br>
<table class=table1 >
	<input type='hidden' name='ssid' value=$ssid><input type='hidden' name='vid' value=$vid>
	<tr style='font-weight:bold;'>
		<td class=td1>Search By Input Date</td>
		<td class=td1>Search By Department</td>

	</tr>
	<tr>
		<td class=td1><input type='date' id='input1' name='input1' value=$input1></td>
		<td class=td1><select id='dept' name='dept'  placeholder='searching by Department' >
							<option value='$dept' selected>".strtoupper($deptname)."</option>
							<option value='all department'>ALL DEPARTMENT</option>
							<option value='frontoffice'>FRONTOFFICE</option>
							<option value='food&beverage'>FOOD&BEVERAGE</option>
							<option value='food&beverageproduct'>FOOD&BEVERAGEPRODUCT</option>
							<option value='housekeeping'>HOUSEKEEPING</option>
							<option value='humanresourcedevelopment'>HUMANRESOURCEDEVELOPMENT</option>
							<option value='engineering'>ENGINEERING</option>
							<option value='management'>MANAGEMENT</option>
									</select></td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1><input type='submit' value='searching'></td>
		<td class=td1>&nbsp&nbsp</td>
		<td class=td1><input type='submit' value='reset'  onclick='resetter();'></td>

	</tr>
</table>
</form>
<br>

<form action='temp_appr.php' method='get' target='_blank'>
<input type='hidden' value='$ssid' name='ssid'></input><input type='hidden' value='$vid' name='vid'></input>
<input type='hidden' value='$input1' name='input1'></input>
<table>
	<tr>

		<td class=td1><b>FORM REQUEST FOR DAILY WORKERS OF ".strtoupper($deptname)."</b></td>
		<td class=td1><input type=submit value='Sign' style='height:40px;width:100px;' onclick='reloader()'></td>
	</tr>
</table>
<br>

<table>
	<tr><td style=' text-align:left;' class=td1 colspan=2><b><i>Form request</i></b></td></tr>
	<tr>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td>Approved</td>
		<td>Rejected</td>
	</tr>
";


$d='0';
$total='0';
while($row1 = mysqli_fetch_row($result1)){

$d++;
//echo $row1[17].'<br>';

print"
	<tr>
		<td style='width:30px;' class=td1>$d]</td>
		<td colspan=4 class=td1>On Date of ".date_format((date_create($input1)),'d F Y' )." <b>Dept. $row1[14] Request for $row1[21] schedule, <i>total Rp ".number_format( $row1[22],0,',','.').",-</i></b></td>
		<td class=td1><input type='checkbox' id='fpapproved$d' name='fpapproved$d' value='$row1[14]'></td>
		<td class=td1><input type='checkbox' id='fprejected$d' name='fprejected$d' value='$row1[14]'></td>
		<td style='width:100px;' class=td1>&nbsp</td>
	</tr>
";

$total=$total+strval($row1[22]);
}



print"
	<tr><td class=td1>&nbsp</td></tr>
	<tr>
		<td class=td1>&nbsp</td>
		<td class=td1 style='text-align:right;'><b>Total Amount <i>Rp ".number_format( $total,0,',','.').",-</i></b></td>
	</tr>
		

	<tr><td class=td1>&nbsp</td></tr>
	<tr><td style=' text-align:left;' class=td1 colspan=2><b><i>Detail</i></b></td></tr>
	<tr><td class=td1>&nbsp</td></tr>
";



print"
	<tr><td class=td1 colspan=2 style='text-align:left;'>
						
";

$e='0';
$deptn='';
while($row2 = mysqli_fetch_row($result2)){
$e++;


	if($row2[14]!=$deptn){
	print"</ul>";
	print"
		<ul><b><i>$row2[14];</i></b>
	";
	$deptn=$row2[14];
			}

	print"
		<li>Date of ".date_format((date_create($row2[5])),'d F Y' )." request for $row2[21] schedule</li>
	";
}
print"
			</ul>
		</td>
	</tr>
";





print"
</form>
</table>
<form action='del_app.php' method='get' target='_blank'>
<br>

<span><button type='button' onclick='details()' id='btnshow'><b>+</b></button><span>
<span><button type='reset' onclick='undetails()' id='btnunshow'><b>-</b></button><span>

<table id='detail' style='display:none;'>
<input type='hidden' name='ssid' value=$ssid><input type='hidden' name='vid' value=$vid>
	<tr>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1>&nbsp</td>
		<td class=td1><input type=submit value='Reject' style='height:30px;width:60px;' onclick='reloader()'></td>
	</tr>
	<tr>		<td class=td1>&nbsp</td></tr>
	<tr>
		<td rowspan=2>NO</td>
		<td rowspan=2>DATE</td>
		<td rowspan=2>NAME OF DW</td>
		<td rowspan=2>SALARY</td>
		<td rowspan=2>TOTAL HOURS</td>
		<td rowspan=2>TOTAL</td>
		<td rowspan=2>REMARK</td>
		<td colspan=1 >STATUS</td>
	</tr>
	<tr>
		<td>Rejected</td>
	</tr>


";


$n='0';
while($row = mysqli_fetch_row($result)){
$n++;

$ganjil=fmod($n+2,2);
	if($ganjil=='1'){$colorbg='#e8e9eb';}else{$colorbg='none';}

print"
	<tr style='background-color:".$colorbg.";'>
		<td rowspan='2'>$n<input type='hidden' id='page' name='page".$n."' value='$row[0]'></td>
	";
	if($row[6]=='0000-00-00'){	
	print"	<td>".date_format((date_create($row[5])),'d F Y' )."</td>	";
			}else{print"<td>".date_format((date_create($row[5])),'d F Y' )." s/d ".date_format((date_create($row[6])),'d F Y' )."</td>";}
	print"
		<td rowspan='2'>".strtoupper($row[12])."</td>
		<td rowspan='2'>Rp ".number_format($row[10],0,',','.').",-</td>
		<td rowspan='2'>".$row[13]."</td>
		<td rowspan='2'>Rp ".number_format($row[11],0,',','.').",-</td>
		<td rowspan='2'>".ucfirst(strtolower($row[17]))."</td>
	";

	print"
		<td rowspan='2'><input type='checkbox' id='rejected' name='rejected".$n."' onclick='disableappr()' value='".$row[0]."'></td>
	</tr>
	";

	if($row[9]!='null'){
				if($row[9]=='A'){$jadwal='15:00 - 23:00';}
				if($row[9]=='A2'){$jadwal='16:00 - 24:00';}
				if($row[9]=='A4'){$jadwal='18:00 - 02:00';}
				if($row[9]=='M'){$jadwal='07:00 - 15:00';}
				if($row[9]=='D1'){$jadwal='09:00 -17:00';}
				if($row[9]=='D2'){$jadwal='10:00 - 18:00';}
				if($row[9]=='SN'){$jadwal='09:00 - 14:00';}
				if($row[9]=='NS'){$jadwal='08:00 - 16:00';}
				if($row[9]=='N'){$jadwal='23:00 - 07:00';}
				if($row[9]=='N2'){$jadwal='23:00 - 02:00';}
				if($row[9]=='D3'){$jadwal='11:00 - 19:00';}
				if($row[9]=='D4'){$jadwal='12:00 - 20:00';}
				if($row[9]=='D5'){$jadwal='13:00 - 21:00';}
				if($row[9]=='D6'){$jadwal='14:00 - 22:00';}
				if($row[9]=='M1'){$jadwal='06:00 - 14:00';}
				if($row[9]=='M2'){$jadwal='07:00 - 15:00';}
				if($row[9]=='EM'){$jadwal='04:00 - 12:00';}
				if($row[9]=='EM'){$jadwal='03:00 - 11:00';}
		print"
	<tr style='background-color:".$colorbg.";'>
		<td>".$row[9]." (".$jadwal.")</td>
	</tr>
		";
			}else{print "<tr style='background-color:".$colorbg.";'><td>".$row[7]." - ".$row[8]."</td></tr>";}
}


print"

</table>
</form>

</div>

</body>
</html>
";

mysqli_close($con);

?>