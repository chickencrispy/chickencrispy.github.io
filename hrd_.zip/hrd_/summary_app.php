<?php

print"

<html>

<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:100px;}
	body{border:solid green 0px;}
	table{border:solid red 0px; font-family:calibri; font-size:13pt; width:100%; border-collapse:collapse}
	tr,td{border:solid grey 1px; text-align:center;border-collapse:collapse;}
</style>

<body>
<div>
<table>
<tr>
	<td>Month</td>
	<td>Years</td>
	<td>Department</td>
	<td>By Date Request</td>
	<td>Name</td>
</tr>
<tr>
	<td><select name='month' id='month'>
			<option value='JANUARY'>JANUARY</option>
			<option value='FEBRUARY'>JANUARY</option>
			<option value='MARCH'>MARCH</option>
			<option value='APRIL'>APRIL</option>
			<option value='MAY'>MAY</option>
			<option value='JUNE'>JUNE</option>
			<option value='JULY'>JULY</option>
			<option value='AUGUST'>AUGUST</option>
			<option value='SEPTEMBER'>SEPTEMBER</option>
			<option value='OKTOBER'>OKTOBER</option>
			<option value='NOVEMBER'>NOVEMBER</option>
			<option value='DECEMBER'>DECEMBER</option>
	</select></td>
	<td><select name='years' id='years'>
			<option value='2022'>2022</option>
			<option value='2021'>2021</option>
			<option value='2020'>2020</option>
			<option value='2019'>2019</option>
			<option value='2018'>2018</option>
	</select></td>
	<td><select name='dept' id='dept'>
			<option value='ALL DEPARTMENT'>ALL DEPARTMENT</option>
			<option value='FRONTOFFICE'>FRONTOFFICE</option>
			<option value='FOOD&BEVERAGE'>FOOD&BEVERAGE</option>
			<option value='HOUSEKEEPING'>HOUSEKEEPING</option>
			<option value='HUMANRESOURCEDEVELOPMENT'>HUMANRESOURCEDEVELOPMENT</option>
			<option value='ENGINEERING'>ENGINEERING</option>
			<option value='MANAGEMENT'>MANAGEMENT</option>
	</select></td>
	<td><input type='date' name='dateinput' id='dateinput'></td>
	<td><input type='search' name='name' id='name'></td>
	<td><input type='submit' value='search'></td>
</tr>
<tr>
	<td><input type='radio' name='radio01' id='radio01'> Daily</td>
	<td><input type='radio' name='radio01' id='radio01'>Monthly</td>
</tr>
</table>
<table>
<tr>
	<td>print</td>
</tr>
</table>
</div>

<div>

<table>
<tr>
	<td colspan='5'>Report Daily Summery by Department of HOUSEKEEPING on June 2022  </td>
</tr>
<tr>
	<td colspan='5'>Report Daily Summery by All Department on June 2022  </td>
</tr>

<tr>
	<td>Date</td>
		<td>Department</td>
	<td>Request Form</td>
	<td>Cost</td>
</tr>
<tr>
	<td>1</td>
		<td>housekeeping</td>
	<td>14</td>
	<td>Rp 500.000,-</td>
</tr>
<tr>
	<td>&nbsp</td>
		<td>&nbsp</td>
	<td>Total Cost</td>
	<td>Rp 200.000,-</td>
</tr>





</body>
</html>

";
?>