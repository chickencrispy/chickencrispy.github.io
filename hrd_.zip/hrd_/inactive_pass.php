<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include 'mysql-connector.php';


$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
if(isset($_REQUEST['akses2'])){$akses2=$_REQUEST['akses2'];}else{$akses2='null';}


//print $ssid.'<br>';
//print $vid.'<br>';
//print $akses2.'<br>';

if(($akses2=='null')){
	print "<script>window.alert('no user deactived');window.history.back();</script>";
}else{

	//**********CEk account***************//
	$result1 = mysqli_query($con, "SELECT * FROM `log`.hrd_dw_pass where d0 like '".$akses2."';");
	$row1 = mysqli_fetch_row($result1);

	//*************set log*******************//
	$result2 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='deactive acount of', d4='".$row1[2]."';");

//**********set inactive***************//
$result = mysqli_query($con, "update `log`.hrd_dw_pass set d8 ='0', d7='', d4='', d2='0' where d0 like '".$akses2."';");





	print "<script>window.alert('user was inactive');window.close();</script>";
}

?>