<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include 'mysql-connector.php';


$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
$page=$_REQUEST['page'];

include 'getip.php';
include 'ver_page.php';

//print $ssid.'<br>';
//print $vid.'<br>';
//print $page.'<br>';



$result= mysqli_query($con, "update hrd.form_dw set d4='3' where d0 like '".$page."';");

//*************set log*******************//
$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='cancel order', d4='".$page."', d5='".$ipuser."';");		



mysqli_close($con);

print"
<script>window.location.assign('cne_app.php?ssid=$ssid&vid=$vid&date1=&input1=&name=&dept=');</script>
";

?>