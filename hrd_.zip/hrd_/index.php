<?php
//---mysql connect---//
include 'mysql-connector.php';

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow = date('Y-m-d H:i:s');
?>

<html>

<head>
	<meta name='viewport' content='width=device-width, initial-scale=1.0'>
	<title>Planet Holiday Hotel & Residences</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
	<link rel="stylesheet" href="assets/css/style.css">
</head>

<body>
	<div class="login-wrapper">
		<?php
			$result = mysqli_query($con, "SELECT *, count(d16) as d18 FROM hrd.form_dw where d3 like '0' and d4 like '1' group by d14;");
			$rows = mysqli_num_rows($result);
			$n = '0';
			//while ($row = mysqli_fetch_row($result)) { $n++; print "<li>Date of <i>" . date_format((date_create($row[1])), 'd F Y') . ",</i> Dept. $row[14] requestion`s under surveilance</li>"; }
			if($rows != 0){
		?>
		<div class="surveilance-bar">
			<div class="alert alert-primary alert-dismissible fade show" role="alert">
				<i class="fa-solid fa-circle-info"></i> <strong>Information:</strong> There are <?php echo ($rows); ?> requestion`s under surveilance.
				<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
			</div>
		</div>
		<?php
			}
		?>

		<div class="login-card">
			<img src="logo.png" style="transform: scale(0.75);">
			<div class="login-card-body">
				<form action="verpass.php" method="post" target="_self">
					<div class="input-group">
						<input type='password' class="form-control" name='sid' id='sid' required='required' autofocus placeholder="Enter passcode">
						<button type="submit" class="btn btn-primary"><i class="fa-solid fa-arrow-right"></i></button>
					</div>
				</form>
			</div>
			<a href='cg_pass.php' target='_self' class="btn btn-link text-reset">Change Passcode</a>
		</div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"></script>
	<script>
		setTimeout(function() {
			window.location.reload(1);
		}, 150000);
	</script>
</body>

</html>

<?php mysqli_close($con); ?>