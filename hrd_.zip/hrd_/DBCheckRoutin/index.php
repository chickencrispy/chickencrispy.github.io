<?php


print"

<!DOCTYPE html>
<html>
<head>
<script src='jquery-3.5.1.min.js'></script>
<script>
// Fungsi untuk memuat ulang div
function reloadDiv() {
  $.ajax({
    url: 'main.php', // File PHP yang mengembalikan konten div baru
    success: function(data) {
      $('#myDiv').html(data); // Mengganti isi div dengan data baru
    }
  });
}

// Panggil fungsi reloadDiv() setiap waktu tertentu
setInterval(reloadDiv, 5000); // Memuat ulang div setiap 5 detik (5000 milidetik)
</script>
</head>
<body>
   <div id='myDiv'>
        <!-- Konten div yang akan diperbarui -->
   </div>
</body>
</html>

";


?>