<?php  

print"
<script type='application/javascript'>

  function getIP(json) {
	var x=json.ip;
	document.cookie = 'ips = ' + x;
  }

</script>
<script type='application/javascript' src='https://api.ipify.org?format=jsonp&callback=getIP'></script>
";

$ipuser=$_COOKIE['ips'];
//print $ipuser;


?>  