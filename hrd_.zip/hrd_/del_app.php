<?php

//---mysql connect---//
include 'mysql-connector.php';

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

print '<b><i>Loading System...........</i></b>';



$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];


include'getip.php';

//print $ssid.'<br>';
//print $vid.'<br>';

if(!empty($_REQUEST['page'])){$rejected=$_REQUEST['page'];}else{$rejected='null';}
//print $rejected.'<br>';


$n='0';
for($i=0;$i<=50;$i++){
if(!empty($_REQUEST['rejected'.$i])){$n++; $rejectedn[$n]=$_REQUEST['rejected'.$i];};
}
//print 'n= '.$n.'<br>';
for($a=1;$a<=$n;$a++){
		//print 'reject'.$a.'= '.$rejectedn[$a].'<br>';
			}


if ($n=='0'){
	//print 'satuan'.'<br>';
		$result1 = mysqli_query($con, "update hrd.form_dw set d4='0', d3='".$ssid."' where d0 like '".$rejected."'");


	//*************set log*******************//
	$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='delete order', d4='".$rejected."', d5='".$ipuser."';");

	print "
	<script language='javascript'>
	setTimeout(function(){
		window.close();
	}, 2000);
	</script>";
}

if ($n>'0'){
	//print 'banyak'.'<br>';
		for($a=1;$a<=$n;$a++){
	//print $rejectedn[$a].'<br>';
			$result1 = mysqli_query($con, "update hrd.form_dw set d4='2', d3='".$ssid."' where d0 like '".$rejectedn[$a]."'");

	//*************set log*******************//
	$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='reject order', d4='".$rejectedn[$a]."', d5='".$ipuser."';");
				}
	print "
	<script language='javascript'>
	setTimeout(function(){
		window.close();
	}, 2000);
	</script>";
}

if (($n=='0')&&($rejected=='null')){

	print "
	<script language='javascript'>
	setTimeout(function(){
		window.alert('Nothing Reject');
		window.close();
	}, 500);
	</script>";

}







?>