<?php
$date1=date_create("2022-06-28 09:00:00");
$date2=date_create("2022-06-29 10:00:00");
$diff=date_diff($date1,$date2);

$tiff=$diff->format("%a days %H Jam %I Menit");
echo $tiff.'<br>';
echo $diff->format("%a days %H Jam %I Menit")."<br>";



$time1 = new DateTime('03:10:00');
$time2 = new DateTime('09:20:00');
$interval = $time1->diff($time2);
echo $interval->format('%H:%I:%S');
?>