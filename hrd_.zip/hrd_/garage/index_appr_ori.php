<?php

//---mysql connect---//
include 'mysql-connector.php';

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');


print"

<html>
<title>Planet Holiday Hotel & Residences</title>



<style>
.center {  margin: auto;  width: 20%;  border: 0px solid green;  padding: 0px;}

div {width:100%; height:20%; background-color:transparent; position:relative; top:25%; right:0px;}
table { width:100%; margin:0px 0px 0px 0px; padding:0px 0px 0px 0px;  border-style:solid; border-width:0px; border-spacing:0px; font-family:verdana; font-size:13px; border-collapse:collapse; }
body { margin:0px; padding:0px; border-style:solid; ; border-width:0px; border-spacing:0px; }
tr { margin:0px; padding:0px; border-style:solid;  border-width:0px; border-spacing:0px;}
td { border-color:#d6d6c2; margin:0px; padding:10px 0 0 0; border-style:solid;  border-width:0px; border-spacing:0px; text-align:center; width:90px; color:#6b6b47;}

.input {margin:0px; padding:0px; border-style:solid;  border-width:1px; border-spacing:0px; background-color:#d6d6c2;}
</style>






<body >

<div class=center>
<table>
	<tr>
		<td style='text-align:center;'><img src='logo.png'></td>
	</tr>
	<tr>
		<td><b><i>PASSCODE</i></b></td>
	</tr>
	<tr>
<form action='verpass_appr.php' method='post' target='_self'>
		<td><input type='password' name='sid' id='sid' required='required' autofocus></td>
	</tr>
	<tr>
		<td style='text-align:center;'><input type='submit' VALUE='NEXT'></td>
	</tr>
	<tr>
		<td style='text-align:center;'><a href='#' target='_self'><b><i><u>Sign Up</u></i></b></a></td>
	</tr>
	<tr>
		<td style='text-align:center;'><a href='#' target='_self'><b><i><u>Change_Pass</u></i></b></a></td>
	</tr>

</form>
</table>
</div>

</body>

</html>


";

print"
<script language='javascript'>
setTimeout(function(){
   window.location.reload(1);
}, 300000);
</script>
";

?>