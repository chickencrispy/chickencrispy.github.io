<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d');

//---mysql connect---//
include 'mysql-connector.php';

include 'vercfg.php';

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
$position=$_REQUEST['position'];


include'ver_page.php';

if(isset($_REQUEST['attr'])){$attr=$_REQUEST['attr'];}else{$attr='';}
if(isset($_REQUEST['akses'])){$akses=$_REQUEST['akses'];}else{$akses='';}
if(isset($_REQUEST['passcode'])){$passcode=$_REQUEST['passcode'];}else{$passcode='';}

//print 'ssid= '.$ssid.'<br>';
//print 'vid= '.$vid.'<br>';
//print 'position= '.$position.'<br>';
//print 'attr= '.$attr.'<br>';
//print 'idakses= '.$akses.'<br>';
//print 'passcode= '.$passcode.'<br>';


	include'access_cfg.php';

if(($attr!='')&&($akses!='')&&($passcode!='')){

//************cek profil********************//
$result2 = mysqli_query($con, "SELECT * FROM hrd.employee_position where d0 like '".$akses."';");
$row2 = mysqli_fetch_row($result2);
//print $row2[3].'<br>';

if($row2[3]=='null'){print"<script>window.alert('missing profile user');</script>";}

//************Cek account********************//
$result3 = mysqli_query($con, "SELECT count(d2) as jmlaccount FROM `log`.hrd_dw_pass where d2 like '".$row2[3]."';");
$row3 = mysqli_fetch_row($result3);
//print $row3[0].'<br>';

if(($row3[0]!='0')&&($row2[3]!='null')){print"<script>window.alert('invalid create double user');</script>";}

if(($row3[0]=='0')&&($row2[3]!='null')){


//print $attr.'<br>';
	//************set account********************//
	$result4 = mysqli_query($con, "insert into `log`.hrd_dw_pass set d2='".$row2[3]."', d4='".md5($passcode)."', d5='admin', d7='".$attr."', d8='1'  ;");

	//*************set log*******************//
	$result6 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='create acount of ', d4='".$row2[3]."';");

	print "<script>window.alert('Passcode was create');window.close();</script>";
		}
				}


//********RESULT***********//
$result = mysqli_query($con, "SELECT employee_position.d0, employee_position.d3, employee_position.d2, chart_organize.d1, chart_organize.d6, dept_organize.d2 FROM hrd.employee_position, hrd.chart_organize, hrd.dept_organize where employee_position.d1 like chart_organize.d0 and chart_organize.d6 like dept_organize.d0 and dept_organize.d0 like '".$position."' limit 50 ;");


print"

<html>
<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:90%;}
	body{border:solid green 0px; padding: 30px 0 0 0;}
	table{border:solid red 0px; font-family:calibri; font-size:11pt; width:100%; border-collapse:collapse}
	td{border:solid grey 0px; text-align:left;}
	.input1{height:50px; font-weight:bold;}

#overflowTest {
  color: white;
  padding: 15px;
  width: 93%;
  height: 150px;
  overflow: auto;
  border: 0px solid #ccc;

</style>
<body>


<div>
<table>
<form action='Account_app.php' method='get' target='_self'>
	<input type='hidden' name='ssid' value='$ssid'><input type='hidden' name='vid' value='$vid'>

	<tr><td style='border-bottom: 1px solid grey' colspan=3><b>BUILD PASSCODE</b></td></tr>
	<tr><td>&nbsp</td></tr>
	<tr>
		<td><b><i>Position</i></b></td>
		<td><b><i><u>List Name</u></i></b></td>
	</tr>
";
	if($position=='%'){$position='ALL DEPARTMENT';}
	if($position=='1'){$position='MANAGEMENT';}
	if($position=='2'){$position='ACCOUNTING';}
	if($position=='3'){$position='FOOD&BEVERAGE';}
	if($position=='4'){$position='HUMANRESOURCEDEVELOPMENT';}
	if($position=='5'){$position='FRONTOFFICE';}
	if($position=='6'){$position='SALES&MARKETING';}
	if($position=='7'){$position='ENGINEERING';}
	if($position=='8'){$position='HOUSEKEEPING';}


print"
	<tr>
		<td><select name='position' id='position' onchange='this.form.submit();'>
			<option value='$position' >$position</option>
			<option value='%'>ALL DEPARTMENT</option>
			<option value='1' >MANAGEMENT</option>
			<option value='2' >ACCOUNTING</option>
			<option value='6' >SALES&MARKETING</option>
			<option value='5' >FRONTOFFICE</option>
			<option value='3' >FOOD&BEVERAGE</option>
			<option value='4' >HUMANRESOURCEDEVELOPMENT</option>
			<option value='8' >HOUSEKEEPING</option>
			<option value='7' >ENGINEERING</option>
		</select></td>
		<td rowspan='5' ><div id='overflowTest'><table>
";
	$n='0';
	while($row = mysqli_fetch_row($result)){
	$n++;
		if(fmod($n,2)=='0'){$bkg='#e8e9eb';}else{$bkg='none';}
		print"
			<tr style='background-color:$bkg;'>
					<td style='width:20px;'>$n]</td>
					<td style='width:200px;'>$row[2]</td><td style='width:200px;'>$row[3]</td><td ><input type='radio' name='akses'  id='akses' value='$row[0]' ></input></td></tr>
		";
					}
print"
		</table></div></td>
	</tr>
	<tr><td><b><i>Atribute</i></b></td></tr>
	<tr><td><input type='radio' name='attr' value='user' checked>User<input type='radio' name='attr' value='admin'>Admin<input type='radio' name='attr' value='super'>Super</td></tr>
	<tr><td><b><i>Passcode</i></b></td></tr>
	<tr><td><input type='text' name='passcode' id='passcode'></td></tr>


	<tr><td rowspan=4>&nbsp</td></tr>
	<tr><td>&nbsp</td></tr>
	<tr><td><b><i><u>User Accessible</u></i></b></td></tr>
	<tr>
		<td rowspan='5' >
			<div id='overflowTest'><table>
";

		$result1 = mysqli_query($con, "SELECT hrd_dw_pass.d0, hrd_dw_pass.d2, employee_position.d2, hrd.employee_position.d1, chart_organize.d1, hrd_dw_pass.d7 FROM `log`.hrd_dw_pass, hrd.employee_position, hrd.chart_organize where hrd_dw_pass.d2 like employee_position.d3 and employee_position.d1 like chart_organize.d0 and hrd_dw_pass.d8 like '1' group by hrd_dw_pass.d0 asc;");
			$n='0';
			while($row1 = mysqli_fetch_row($result1)){
			$n++;
				if(fmod($n,2)=='0'){$bkg='#e8e9eb';}else{$bkg='none';}
				print"
				<tr style='background-color:$bkg;'>
						<td style='width:20px;'>$n]</td>
						<td style='width:200px;'>$row1[2]</td><td style='width:200px;'>$row1[4]</td><td><input type='radio' name='akses2' id='akses2' value='$row1[0]' ></input></td>
				";
					if($row1[5]==$user){$stat='user';}
					if($row1[5]==$admin){$stat='admin';}
					if($row1[5]==$super){$stat='super';}
				print"
						<td>Access of <b>".ucfirst($stat)."</b></td>
				</tr>
				";
							}
print"
			</table></div>
		</td>
	</tr>
</table>
<br>
<table>
	<tr>
	<td style='width:100px;'><input type='submit' value='Create' class=input1></td>
	<td style='width:100px;'><input type='submit' value='Update' class=input1 formaction='update_pass.php'></td>
	<td><input type='submit' value='Inactive' class=input1 formaction='inactive_pass.php'></td>
	</tr>
</table>

</div>
</body>
</html>

";


?>