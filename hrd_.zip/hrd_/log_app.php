<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include 'mysql-connector.php';

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
$tiket=$_REQUEST['tiket'];

include'ver_page.php';

print"
<html>
<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:98%; height:1000px;}
	body{border:solid green 0px; padding:10px 0 0 0;}
	table{border:solid red 0px; font-family:verdana; font-size:9pt;  border-collapse:collapse}
	td{border:solid grey 0px; text-align:left;}
	.td1{border:solid grey 1px; text-align:center;}
	a{text-decoration:none; color:red;}
</style>
<body>
<div>

<form action='log_app.php' method='get' target='_self'>
<table>
	<input type='hidden' name='ssid' value='$ssid'><input type='hidden' name='vid' value='$vid'>
	<tr>
		<td style='width:150px;'>Find Ticket Order</td>
		<td style='width:10px;'>:</td>
		<td style='width:150px;'><input type='text' name='tiket' id='tiket' ></td>
		<td><input type='submit' value='Search'></td>
	</tr>
</table>
<br>
<table>
";

$result = mysqli_query($con, "SELECT * FROM hrd.form_dw where d0 like '".$tiket."' ;");
$row = mysqli_fetch_row($result);

	if($row[0]!=''){
print"
	<tr><td style='border-bottom: 1px solid grey' colspan='6'><b>ORDER OF $row[0]</b></td></tr>
	<tr><td>&nbsp</td></tr>

	<tr>
		<td class=td1><b>Date</b></td>
		<td class=td1><b>Name of DW</b></td>
		<td class=td1><b>Department</b></td>
		<td class=td1><b>Salary</b></td>
		<td class=td1><b>Total Hours</b></td>
		<td class=td1><b>Total</b></td>
		<td class=td1><b>Remark</b></td>
		<td class=td1><b>Status</b></td>
	</tr>
	<tr>
		<td class=td1>".date_format((date_create($row[5])),'d F Y' )."</td>
		<td class=td1>$row[12]</td>
		<td class=td1>$row[14]</td>
		<td class=td1>Rp ".number_format($row[10],0,',','.').",-</td>
		<td class=td1>$row[13]</td>
		<td class=td1>Rp ".number_format($row[11],0,',','.').",-</td>
		<td class=td1>$row[17]</td>
";
		if($row[4]=='0'){$status='Deleted';}
		if($row[4]=='1'){$status='Archived';}
		if($row[4]=='2'){$status='Rejected';}
		if($row[4]=='3'){$status='Canceled';}

	print"
		<td class=td1>$status</td>
	";
print"
	</tr>
";
}

print"

</table>
<br>
<table>
	<tr>
		<td style='border-bottom: 1px solid grey'><b><i>Action</i></b></td>
	</tr>
";


//*************set log*******************//
$result = mysqli_query($con,"SELECT * FROM `log`.log_dw_app order by d0 desc limit 200;");



$n='0';
while($row = mysqli_fetch_row($result)){
$n++;

//*************set log*******************//
$result2 = mysqli_query($con,"SELECT employee_position.d1, employee_position.d2, employee_position.d3, chart_organize.d1, chart_organize.d6, dept_organize.d2 FROM hrd.employee_position, hrd.chart_organize, hrd.dept_organize where employee_position.d3 like '".$row[2]."' and chart_organize.d0 like employee_position.d1 and dept_organize.d0 like chart_organize.d6;");
$row2 = mysqli_fetch_row($result2);

print"
	<tr><td>$n] $row[1] Account of $row2[3] $row[3] <a href='log_app.php?ssid=$ssid&vid=$vid&tiket=$row[4]'>$row[4]</a> <-- $row[5]</td></tr>
";

}


print"

</table>
</div>
</body>
</html>
";

mysqli_close($con);
?>