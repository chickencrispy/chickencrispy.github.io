<?php


print "
<html>
<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:0px; height:0px;}
	body{border:solid green 0px; padding:10px 0 0 0;}
	table{border:solid red 0px; font-family:calibri; font-size:11pt; width:50%; //border-collapse:collapse}
	tr, td{border:solid grey 1px; text-align:left;}
	select{border:solid grey 1px; height:50px; font-size:12pt;}
</style>
";

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");

//---mysql connect---//
include 'mysql-connector.php';


$result6 = mysqli_query($con, "SELECT * FROM `log`.hrd_dw_pass where d2 like '2291';");
$row6 = mysqli_fetch_row($result6);


//if($vid!=$row6[3]){print"<script>window.alert('user expired');window.location.assign('index.php');</script>";}
//if($ssid==''){print"<script>window.alert('user expired');window.location.assign('index.php');</script>";}
//if($vid==''){print"<script>window.alert('user expired');window.location.assign('index.php');</script>";}


//*************CEK USER ONLINE TO OFFLINE***********//

$timelogin1=date_create(date('H:i:s'));
$timelogin2=($timelogin1->format("h"))+1;
//print $timelogin2.'<br>';


$dateN=date_create(date('Y-m-d H:i:s'));
//print $dateN->format("H:i:s").'<br>';
date_add($dateN,date_interval_create_from_date_string("1 Hours"));
$dateN1=date_format($dateN,'Y-m-d H:i:s');
//print $dateN1.'<br>';



$timelogin1=date('Y-m-d H:i:s');
$timelogin2=$row6[6];

//print $timelogin1.'<br>';
//print $timelogin2.'<br>';

if($timelogin1>=$timelogin2){print"logoff";}else{print"online<br>";}

$time1 = new DateTime('01:00:00');
$time2 = new DateTime('02:00:00');
$interval = $time1->diff($time2);
echo $interval->format('%h');









$result2 = mysqli_query($con, "SELECT *, count(d5) as d18 FROM hrd.form_dw where d3 like '0' and d1 like '2022-08-04' and d4 like '1' and d14 like '%' group by d16;");

//$result3 = mysqli_query($con, "");




print"
<body>

<div>
<table>
<tr><td><ul>
";

$deptn='';
while($row2 = mysqli_fetch_row($result2)){

if($row2[14]!=$deptn){
print"
$row2[14]
";
$deptn=$row2[14];
}

print"
<li>$row2[0]</li>
";

}

print"
</ul></td>

</tr>
</table>
</div>

</body>
<html>
";



$result7 = mysqli_query($con, "SELECT * FROM `log`.log_dw_app order by d0 desc;");
while($row7 = mysqli_fetch_row($result7)){
//print "$row7[0] | $row7[1] | $row7[2] | $row7[3] | $row7[4]<br> ";
}



print"
<script language='javascript'>

setTimeout(function(){
//window.alert('hello');
//window.location.reload();
}, 3000);
</script>

";


print"
<script type='text/javascript'>


  $('#myStyle').load('data.php);

</script>


<body>
<div id='myStyle'>
</div>
</body>
";



$result1 = mysqli_query($con,"SELECT hrd_dw_pass.d2, employee_position.d2, chart_organize.d1, chart_organize.d0, hrd_dw_pass.d7 FROM `log`.hrd_dw_pass, hrd.employee_position, hrd.chart_organize where hrd_dw_pass.d2 like '2291' and employee_position.d3 like hrd_dw_pass.d2 and chart_organize.d0 like employee_position.d1;");
$row1 = mysqli_fetch_row($result1);


print $row1[4].'<br>';

$begin2=strpbrk($row1[4], 'S');
$begin=substr($row1[4],-1,1);
print $begin2.'<br>';
print $begin.'<br>';








$tglnow=date('Y-m-01');
$jml_hari=date("t",strtotime($tglnow));
print 'jml_hari= '.$jml_hari.'<br>';

print"
<table>
<tr>
<td style='width:100px;'><b>Name of DW :</b></td>
<td><input type='text'></td>
</tr>
</table>
";

print"

<script>
document.getElementById('demo').innerHTML = 'Hello World';
</script>
<div><p id='demo'></p></div>


";



print"<table><tr>";

for($j=0;$j<=$jml_hari;$j++){

$day1=date('Y-m-'.$j);
$day2=date('D',strtotime($day1));

if (fmod($j,7)==0){print"<tr>";}

if($j=='0'){print "<td>&nbsp</td>";}else{
	if($day2=='Sun'){$sun='red;'; $clr='white;';}else{$sun='#f0f2f1;'; $clr='black;';}
	print "<td style=' background-color:$sun height:50px;width:0px;vertical-align:text-top;'>
		<table>
			<tr><td style='color:$clr'><i>$day2</i></td></tr>
			<tr><td><div><p id='demo'></p></div></td><td style='font-size:16pt;'>$j</td>
				<td ><select name='sch$j' id='sch$j' >
					<option value='null'>-</option>
					<option value='A'>A</option>
					<option value='M'>M</option>
					<option value='D1'>D1</option>
					<option value='D2'>D2</option>
					<option value='SN'>SN</option>
					<option value='NS'>NS</option>
					<option value='N'>N</option>
					<option value='D3'>D3</option>
					<option value='D4'>D4</option>
					<option value='D5'>D5</option>
					<option value=D6>D6</option>
					<option value='M1'>M1</option>
					<option value='M2'>M2</option>
					<option value='EM'>EM</option>
				</select></td>
			</tr>
		</table>
	</td>";
}

}

print"</tr></table>";




//*********get mac client akses*********//
$mac='';
foreach(explode("\n",str_replace(' ','',trim(`getmac`,"\n"))) as $i)
if(strpos($i,'Tcpip')>-1){$mac=substr($i,0,17);break;}
print 'mac - '.$mac.'<br>';


$host = gethostbyaddr($_SERVER["REMOTE_ADDR"]);
echo $host;



$to='strengeract@gmail.com';
$from='edp.planetholidayhotel.com@gmail.com';
$message='only test';
$headers='From; $from\n';
mail($to,'',$message,$headers);





?>