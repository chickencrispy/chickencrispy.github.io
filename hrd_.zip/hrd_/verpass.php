<?php


//-----mysql----//
include 'mysql-connector.php';

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");

$tglnow=date("Y-m-d H:i:s");
//print $tglnow."<br>";

if(!empty($_POST['sid'])){$sid=$_REQUEST['sid'];}else{ $sid='';}
//print $sid.'<br>';

$sidmd5=md5($sid);
//-----------CEK DATA md5---------//
$result1 = mysqli_query($con,"SELECT * FROM `log`.hrd_dw_pass where d4 like '".$sidmd5."' and d8 like '1';");
$row1 = mysqli_fetch_row($result1);
//print $row1[2]."<br>";


if ($sidmd5==$row1[4]){

$vid=substr(sha1(mt_rand()),17,20);

//print $vid;

//***********set pass timelogin**************//
$dateN=date_create(date('Y-m-d H:i:s'));
//print $dateN->format("H:i:s").'<br>';
date_add($dateN,date_interval_create_from_date_string("1 Hours"));
$dateN1=date_format($dateN,'Y-m-d H:i:s');
//print $dateN1.'<br>';


$result2 = mysqli_query($con,"update`log`.hrd_dw_pass set d1='".$tglnow."', d6='".$dateN1."' where d2 like '".$row1[2]."';");

$result3 = mysqli_query($con,"update`log`.hrd_dw_pass set d3='".$vid."' where d2 like '".$row1[2]."';");



//*************set log*******************//
$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$row1[2]."', d3='login';");



print"
<script>
window.location.assign('main.php?ssid=$row1[2]&vid=$vid');
</script>
";

}else{

print"
<script>
window.history.back();
</script>
";



}


?>