<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include 'mysql-connector.php';

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
$page=$_REQUEST['page'];

if(isset($_REQUEST['cgname'])){$cgname=$_REQUEST['cgname'];}else{$cgname='';}

//print $cgname.'<br>';
//print $ssid.'<br>';
//print $vid.'<br>';
//print $page.'<br>';


//*******GET NAME DW***************//
$result1= mysqli_query($con, "SELECT * FROM hrd.form_dw where d0 like'".$page."';");
$row1 = mysqli_fetch_row($result1);

print"
<html>
<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:1000px;}
	body{border:solid green 0px; padding:10px 0 0 0;}
	table{border:solid red 0px; font-family:calibri; font-size:11pt; width:0px; border-collapse:collapse}
	td{border:solid grey 0px; text-align:left;}
	input{border:1px solid grey; background-color:#e8e5dc; font-weight:bold;}
</style>


<body>

<div>
<table>
<form action='cg_name.php' method='get' target='_self' >

<input type='hidden' value='$ssid' name='ssid'>
<input type='hidden' value='$vid' name='vid'>
<input type='hidden' value='$page' name='page'>

	<tr><td><b><i>Name Before</b></td></tr>
	<tr>
		<td><input type='text' value='".$row1[12]."' readonly></td>
	</tr>
<tr><td>&nbsp</td></tr>
	<tr><td><b><i>Change Name Here</b></td></tr>

	<tr>
		<td><input type='text' name='cgname' id='cgname' required autofocus></td>
	</tr>
<tr><td>&nbsp</td></tr>
	<tr>
		<td><input type='submit' value='SAVE'></td>
	</tr>
</form>
</table>
</div>

</body>
</html>
";


if($cgname!=''){
	$result= mysqli_query($con, "update hrd.form_dw set d12='".strtoupper($cgname)."' where d0 like '".$page."';");

	//*************set log*******************//
	$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='change name order', d4='".$page."';");

print"
<script>window.location.assign('cne_app.php?ssid=$ssid&vid=$vid&date1=&input1=&name=&dept=');</script>
";
}


mysqli_close($con);


?>