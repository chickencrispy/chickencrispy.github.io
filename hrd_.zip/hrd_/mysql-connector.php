<?php

$servertype="mysql";
//$serverhost="192.168.0.104";
$serverhost="103.246.3.2";
$dbname="plhotel2";
$dbuser="phh_admin";
$dbpassword="phh433555";

$con = mysqli_connect($serverhost,$dbuser,$dbpassword,$dbname);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

?>