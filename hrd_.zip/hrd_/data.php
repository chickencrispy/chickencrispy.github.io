<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");

//---mysql connect---//
include 'mysql-connector.php';

  
$result7 = mysqli_query($con, "SELECT * FROM `log`.log_dw_app order by d0 desc;");
while($row7 = mysqli_fetch_row($result7)){
print "$row7[0] | $row7[1] | $row7[2] | $row7[3] | $row7[4]<br> ";
}
?>