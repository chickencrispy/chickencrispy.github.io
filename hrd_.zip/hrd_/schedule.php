<?php

//---mysql connect---//
include 'mysql-connector.php';

include 'vercfg.php';

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
$main=$_REQUEST['main'];

//print $main."<br>";
include'ver_page.php';

if ($main=='01'){include"../schedule/rpt_sch_edit.php";}
if ($main=='02'){include"../schedule/edit_sch.php";}



?>