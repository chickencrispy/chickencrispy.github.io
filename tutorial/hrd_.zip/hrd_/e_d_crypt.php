<?php


$pass='P4ssny4b4ru';
print $pass.'<br>';
$count=strlen($pass);


print"//****encrypt*******//<br>";
$Epass='';
$arr1 = str_split($pass);
print_r($arr1).'<br>';
print "<br>";
for ($n=0;$n<=$count-1;$n++){
	$arr1[$n]=chr((ord($arr1[$n]))-16);
$Epass=$Epass.$arr1[$n];
}
print_r($arr1);
print "<br>";
print $Epass;
print "<br>";


print"//*******decrypt******//<br>";
$Rpass='';
$arr2=str_split($Epass);
print_r($arr2).'<br>';
print "<br>";

for ($n=0;$n<=$count-1;$n++){
	$arr2[$n]=chr((ord($arr2[$n]))+16);
$Rpass=$Rpass.$arr2[$n];
}
print_r($arr2);
print "<br>";
print $Rpass;
print "<br>";


//$str = ord('N');
//print chr($str+16).'<br>';

?>