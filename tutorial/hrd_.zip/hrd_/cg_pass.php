<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include 'mysql-connector.php';



if(isset($_REQUEST['pass'])){$pass=$_REQUEST['pass'];}else{$pass='';}
if(!empty($_REQUEST['cgpass'])){$cgpass=$_REQUEST['cgpass'];}else{ $cgpass='';}

//if(!empty($_POST['pass'])){$pass=$_REQUEST['pass'];}else{$pass='';}
//if(!empty($_POST['cgpass'])){$cgpass=$_REQUEST['cgpass'];}else{ $cgpass='';}


//print 'pass= '.$pass.'<br>';
//print 'cgpass= '.$cgpass.'<br>';




//-----------CEK DATA---------//
$result = mysqli_query($con,"SELECT * FROM `log`.hrd_dw_pass where d4 like '".$pass."';");
$row = mysqli_fetch_row($result);
//print $row[0].'<br>';




$passmd5=md5($pass);
//print "<script>window.alert('$passmd5')</script>";
//-----------CEK DATA---------//
$result1 = mysqli_query($con,"SELECT * FROM `log`.hrd_dw_pass where d4 like '".$passmd5."';");
$row1 = mysqli_fetch_row($result1);
//print "<script>window.alert('$row1[4]')</script>";


	$valid=0;
if((($row[4]==$pass)or($row1[4]==$passmd5))&&($cgpass!='')){

$cgpass=md5($cgpass);
//print "<script>window.alert('$cgpass')</script>";

//******CEK PASS SAME AS**************//
$result2= mysqli_query($con, "SELECT locate ('".$cgpass."',d4) as pasc FROM `log`.hrd_dw_pass where locate ('".$cgpass."',d4)>0;");
$row2 = mysqli_fetch_row($result2);
//print $row2[0].'<br>';


	if($row2[0]==''){
		$valid='1';
		$vid=substr(sha1(mt_rand()),17,20);

		//-----------UPDATE DATA-----------//
		//$result3= mysqli_query($con, "update `log`.hrd_dw_pass set d4='".$cgpass."', d1='".$tglnow."' where d0 like '".$row[0]."';");
		//-----------UPDATE DATA-----------//
		$result4= mysqli_query($con, "update `log`.hrd_dw_pass set d4='".$cgpass."', d1='".$tglnow."' where d0 like '".$row1[0]."';");
		//-----------UPDATE DATA-----------//
		$result5= mysqli_query($con, "update `log`.hrd_dw_pass set d3='".$vid."' where d0 like '".$row1[0]."';");

		//print $vid;
		print "
		<script>
		alert('passcode was changed');
		window.location.assign('index.php');
		</script>
		";
	}else{
		print "<script>alert('please use another new passcode');</script>";
	}


}

if(($row[4]!=$pass)and($valid==0)){
print"
<script>
	alert('old passcode not valid');
	window.location.assign('index.php');
</script>
";
}
print"

<html>
<title>Planet Holiday Hotel & Residences</title>



<style>
.center {  margin: auto;  width: 20%;  border: 0px solid green;  padding: 0px;}

div {width:100%; height:20%; background-color:transparent; position:relative; top:25%; right:0px;}
table { width:100%; margin:0px 0px 0px 0px; padding:0px 0px 0px 0px;  border-style:solid; border-width:0px; border-spacing:0px; font-family:verdana; font-size:13px; border-collapse:collapse; }
body { margin:0px; padding:0px; border-style:solid; ; border-width:0px; border-spacing:0px; }
tr { margin:0px; padding:0px; border-style:solid;  border-width:0px; border-spacing:0px;}
td { border-color:#d6d6c2; margin:0px; padding:10px 0 0 0; border-style:solid;  border-width:0px; border-spacing:0px; text-align:center; width:90px; color:#6b6b47;}

.input {margin:0px; padding:0px; border-style:solid;  border-width:1px; border-spacing:0px; background-color:#d6d6c2;}
</style>

<body>

<div class=center>
<table>
	<tr><td style='text-align:center;'><img src='logo.png'></td></tr>
<form action='cg_pass.php' method='post' target='_self'>
	<tr><td><b><i>OLD PASSCODE</i></b>&nbsp<input type='password' name='pass' id='pass' required='required' autofocus></td></tr>
	<tr><td><b><i>NEW PASSCODE</i></b>&nbsp<input type='password' name='cgpass' id='cgpass' required='required' autofocus></td></tr>
	<tr>
		<td style='text-align:center;'><input type='submit' VALUE='UPDATE'></td>
	</tr>
</form>
</table>
</div>

</body>

</html>




";
?>