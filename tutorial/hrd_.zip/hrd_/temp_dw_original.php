<?php

//---mysql connect---//
include 'mysql-connector.php';

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
//print $ssid.'<br>';
//print $vid.'<br>';



//***********get dept.**************//
$result1 = mysqli_query($con,"SELECT employee_position.d1, employee_position.d2, employee_position.d3, chart_organize.d1, 
			chart_organize.d6, dept_organize.d2 FROM hrd.employee_position, hrd.chart_organize, 
			hrd.dept_organize where employee_position.d3 like '".$ssid."' and chart_organize.d0 like employee_position.d1 and dept_organize.d0 like chart_organize.d6;");

$row1 = mysqli_fetch_row($result1);
//print $row1[1].'<br>';
//print $row1[5].'<br>';


$deptnm1=strtolower(str_replace(' ','',$row1[5]));

if($deptnm1=='frontoffice'){$deptnm1='fo';}
if($deptnm1=='housekeeping'){$deptnm1='hk';}
if($deptnm1=='humanresourcedevelopment'){$deptnm1='hr';}
if($deptnm1=='food&beverage'){$deptnm1='fb';}
if($deptnm1=='engineering'){$deptnm1='en';}

//print $deptnm1.'<br>';



$codedate1=$_REQUEST['date1'];

$codedate2=str_replace('-','',$codedate1);

//print $codedate2.'<br>';



echo'<b><i>Loading system..........</i></b><br>';


if(isset($_REQUEST['name'])){$name[0]=$_REQUEST['name'];}else{$name[0]='null';}if($name[0]==''){$name[0]='null';}
if(isset($_REQUEST['date1'])){$date1[0]=$_REQUEST['date1'];}else{$date1[0]='null';}if($date1[0]==''){$date1[0]='null';}
if(isset($_REQUEST['date2'])){$date2[0]=$_REQUEST['date2'];}else{$date2[0]='null';}if($date2[0]==''){$date2[0]='null';}
if(isset($_REQUEST['time1'])){$time1[0]=$_REQUEST['time1'];}else{$time1[0]='null';}if($time1[0]==''){$time1[0]='null';}
if(isset($_REQUEST['time2'])){$time2[0]=$_REQUEST['time2'];}else{$time2[0]='null';}if($time2[0]==''){$time2[0]='null';}
if(isset($_REQUEST['time3'])){$time3[0]=$_REQUEST['time3'];}else{$time3[0]='null';}if($time3[0]==''){$time3[0]='null';}
if(isset($_REQUEST['salary'])){$salary[0]=$_REQUEST['salary'];}else{$salary[0]='null';}if($salary[0]==''){$salary[0]='null';}
//print $salary[0].'<br>';
if(isset($_REQUEST['rmkDW'])){$rmkDW[0]=$_REQUEST['rmkDW'];}else{$rmkDW[0]='null';}if($rmkDW[0]==''){$rmkDW[0]='null';}



for($i=1;$i<=9;$i++){
	if(isset($_REQUEST['name'.$i])){$name[$i]=$_REQUEST['name'.$i];}else{$name[$i]='null';}if($name[$i]==''){$name[$i]='null';}
	//if($name[$i]!='null'){print 'name['.$i.'] '.$name[$i]."<br>";}
		}
for($i=1;$i<=9;$i++){
	if(isset($_REQUEST['date1'.$i])){$date1[$i]=$_REQUEST['date1'.$i];}else{$date1[$i]='null';}if($date1[$i]==''){$date1[$i]='null';}
	//if($date1[$i]!='null'){print 'date1['.$i.'] '.$date1[$i]."<br>";}
		}
for($i=1;$i<=9;$i++){
	if(isset($_REQUEST['date2'.$i])){$date2[$i]=$_REQUEST['date2'.$i];}else{$date2[$i]='null';}if($date2[$i]==''){$date2[$i]='null';}
	//if($date2[$i]!='null'){print 'date2['.$i.'] '.$date2[$i]."<br>";}
		}
for($i=1;$i<=9;$i++){
	if(isset($_REQUEST['time1'.$i])){$time1[$i]=$_REQUEST['time1'.$i];}else{$time1[$i]='null';}if($time1[$i]==''){$time1[$i]='null';}
	//if($time1[$i]!='null'){print 'time1['.$i.'] '.$time1[$i]."<br>";}
		}
for($i=1;$i<=9;$i++){
	if(isset($_REQUEST['time2'.$i])){$time2[$i]=$_REQUEST['time2'.$i];}else{$time2[$i]='null';}if($time2[$i]==''){$time2[$i]='null';}
	//if($time2[$i]!='null'){print 'time2['.$i.'] '.$time2[$i]."<br>";}
		}
for($i=1;$i<=9;$i++){
	if(isset($_REQUEST['time3'.$i])){$time3[$i]=$_REQUEST['time3'.$i];}else{$time3[$i]='null';}if($time3[$i]==''){$time3[$i]='null';}
	//if($time3[$i]!='null'){print 'time3['.$i.'] '.$time3[$i]."<br>";}
		}
for($i=1;$i<=9;$i++){
	if(isset($_REQUEST['salary'.$i])){$salary[$i]=$_REQUEST['salary'.$i];}else{$salary[$i]='null';}if($salary[$i]==''){$salary[$i]='null';}
	//if($salary[$i]!='null'){print 'salary['.$i.'] '.$salary[$i]."<br>";}
		}

for($i=1;$i<=9;$i++){
	if(isset($_REQUEST['rmkDW'.$i])){$rmkDW[$i]=$_REQUEST['rmkDW'.$i];}else{$rmkDW[$i]='null';}if($rmkDW[$i]==''){$rmkDW[$i]='null';}
	//if($rmkDW[$i]!='null'){print 'rmkDW['.$i.'] '.$rmkDW[$i]."<br>";}
		}

//print $rmkDW[0].'<br>';
//print $rmkDW[1].'<br>';


$totalhours='0';
$day='';
$time='';
$timef='null';
$database='0';
$totalsalary='0';
$countsalary='0';


for($i=0;$i<=9;$i++){
	if($name[$i]!='null'){
		if($salary[$i]=='null'){$salary[$i]='20000';}


		if(($date1[$i]!='null')or($date2[$i]!='null')){$day='1';$time='0';$totalhours='0';}
		if(($date1[$i]!='null')&&($date2[$i]!='null')){$day='0';$time='0';$totalhours='0';}
		if(($time1[$i]!='null')&&($time2[$i]!='null')){$day='0';$time='2';$totalhours='0';}

		if(($day=='1')&&($time=='0')){
			if($time3[$i]=='A'){$timef='8';}
			if($time3[$i]=='M'){$timef='8';}
			if($time3[$i]=='D1'){$timef='8';}
			if($time3[$i]=='D2'){$timef='9';}
			if($time3[$i]=='SN'){$timef='5';}
			if($time3[$i]=='NS'){$timef='8';}
			if($time3[$i]=='N'){$timef='8';}
			if($time3[$i]=='D3'){$timef='8';}
			if($time3[$i]=='D4'){$timef='8';}
			if($time3[$i]=='D5'){$timef='8';}
			if($time3[$i]=='D6'){$timef='8';}
			if($time3[$i]=='M1'){$timef='8';}
			if($time3[$i]=='M2'){$timef='8';}
			if($time3[$i]=='EM'){$timef='8';}

		$totalhours=$timef.' hours';
				$countsalary=$timef;
					}
		if(($day=='0')&&($time=='2')){
			//echo $time1[$i]."<br>";
			$timer1=date_create($time1[$i].':00');
			$timer2=date_create($time2[$i].':00');
			$diff=date_diff($timer1,$timer2);
			$tiff=$diff->format("%h");
			$totalhours=$tiff." hours";
				$countsalary=$tiff;
					}
		if(($day=='0')&&($time=='0')){
			if($time3[$i]=='A'){$timef='8 hours';}
			if($time3[$i]=='M'){$timef='8 hours';}
			if($time3[$i]=='D1'){$timef='8 hours';}
			if($time3[$i]=='D2'){$timef='9 hours';}
			if($time3[$i]=='SN'){$timef='5 hours';}
			if($time3[$i]=='NS'){$timef='8 hours';}
			if($time3[$i]=='N'){$timef='8 hours';}
			if($time3[$i]=='D3'){$timef='8 hours';}
			if($time3[$i]=='D4'){$timef='8 hours';}
			if($time3[$i]=='D5'){$timef='8 hours';}
			if($time3[$i]=='D6'){$timef='8 hours';}
			if($time3[$i]=='M1'){$timef='8 hours';}
			if($time3[$i]=='M2'){$timef='8 hours';}
			if($time3[$i]=='EM'){$timef='8 hours';}

			$dater1=date_create($date1[$i]);
			$dater2=date_create($date2[$i]);
			$differ=date_diff($dater1,$dater2);
			$datediff=$differ->format("%a");
			$totalhours=(strval($datediff)+1)." days (".$timef.")";
				$countsalary=$datediff+1;
					}
		if(($day=='0')&&($time=='2')&&($date1[$i]!='null')&&($date2[$i]!='null')){
			$dater1=date_create($date1[$i].' '.$time1[$i].':00');
			$dater2=date_create($date2[$i].' '.$time2[$i].':00');
			$difftime=date_diff($dater1,$dater2);
			$datedifftime=$difftime->format("%a days (%h");
			//$totalhours=$datedifftime." hours)";
					$dy=($difftime->format("%a"))+1;
					$hr=$difftime->format("%h");
						if($dy!='0'){$totalhours=$dy.' days ('.$hr.' hours)';}else{$totalhours=$difftime->format("%h hours");}
				if($dy!='0'){$countsalary=$dy;}
				if($dy=='0'){$countsalary=$hr;}
									}
		//*******************moreDayPerjamMalam***************************************//
		if(($day=='0')&&($time=='2')&&($date1[$i]!='null')&&($date2[$i]!='null')&&($time1[$i]>$time2[$i])){
			$dater1=date_create($date1[$i].' '.$time1[$i].':00');
			$dater2=date_create($date2[$i].' '.$time2[$i].':00');
			$difftime=date_diff($dater1,$dater2);
			$datedifftime=$difftime->format("%a days (%h");
			//$totalhours=$datedifftime." hours)";
					$dy=($difftime->format("%a"))+2;
					$hr=$difftime->format("%h");
						if($dy!='0'){$totalhours=$dy.' days ('.$hr.' hours)';}else{$totalhours=$difftime->format("%h hours");}
				if($dy!='0'){$countsalary=$dy;}
				if($dy=='0'){$countsalary=$hr;}
									}
		//**********************1DayPerjamMalam***********************************//
		if(($day=='0')&&($time=='2')&&($date1[$i]!='null')&&($date2[$i]=='null')&&($time1[$i]>$time2[$i])){
				$dateN=date_create($date1[$i]);
				date_add($dateN,date_interval_create_from_date_string("1 days"));
				$dateN1=date_format($dateN,'Y-m-d');
			$dater1=date_create($date1[$i].' '.$time1[$i].':00');
			$dater2=date_create($dateN1.' '.$time2[$i].':00');
			$difftime=date_diff($dater1,$dater2);
			$difftime=date_diff($dater1,$dater2);
			$datedifftime=$difftime->format("%a days (%h");
			//$totalhours=$datedifftime." hours)";
					$dy=($difftime->format("%a"));
					$hr=$difftime->format("%h");
						if($dy!='0'){$totalhours=$dy.' days ('.$hr.' hours)';}else{$totalhours=$difftime->format("%h hours");}
				if($dy!='0'){$countsalary=$dy;}
				if($dy=='0'){$countsalary=$hr;}				
							}

		if(($day=='1')&&($time=='0')){$totalsalary=$salary[$i];}else{$totalsalary=$salary[$i] * $countsalary;}
		if(($day=='0')&&($time=='2')&&($time3[$i]=='null')&&($date1[$i]!='null')&&($date2[$i]!='null')&&($time1[$i]<$time2[$i])){$totalsalary=$salary[$i] * $countsalary * $hr;}			
		if(($day=='0')&&($time=='2')&&($time3[$i]=='null')&&($date1[$i]!='null')&&($date2[$i]!='null')&&($dy!='0')){$totalsalary=$salary[$i] * $countsalary * $hr;}			


		//if(($day=='1')&&($time=='0')){$totalsalary=$salary[$i];}else{$totalsalary=$salary[$i].'('.$countsalary.')';}
		//if(($day=='0')&&($time=='2')&&($time3[$i]=='null')&&($date1[$i]!='null')&&($date2[$i]!='null')&&($time1[$i]<$time2[$i])){$totalsalary=$salary[$i].'('.$countsalary.')'.$hr;}			
		//if(($day=='0')&&($time=='2')&&($time3[$i]=='null')&&($date1[$i]!='null')&&($date2[$i]!='null')&&($dy!='0')){$totalsalary=$salary[$i].'('.$countsalary.')'.$hr;}			

		
		//if(( ($day=='0')&&($time=='2') )&&( ($date1[$i]=='null')or($date2[$i]=='null'))&&($time1[$i]>=$time2[$i])  ){print"<script>window.alert('Jam melebihi Tanggal, Cek dinama '+'$name[$i]');</script>";$database='1';print"<script>window.close();</script>";}
		if ($date1[$i]==$date2[$i]){print"<script>window.alert('Tanggal tidak boleh sama (untuk DW 1 hari cukup isi tgl di kolom pertama, Cek dinama '+'$name[$i]');</script>";$database='1';print"<script>window.close();</script>";}
		
		if(($time1[$i]=='null')&&($time2[$i]=='null')&&($time3[$i]=='null')){print"<script>window.alert('Jadwal Kosong, Cek dinama '+'$name[$i]');</script>";$database='1';print"<script>window.close();</script>";}

		//echo $name[$i].'|'.$date1[$i].'|'.$date2[$i].'|'.$time1[$i].'|'.$time2[$i].'|'.$time3[$i].'|'.$salary[$i].'|<b>'.$day.'</b>|<b>'.$time.'</b>'.'|'.$totalhours.'|'.$countsalary.'|'.$totalsalary.'<br>';

			}


$row1[5]=str_replace(' ','',$row1[5]);

if($database!='1'){
		if ($name[$i]!='null'){
$result = mysqli_query($con, "insert into hrd.form_dw set 
	d0='', 
	d1='".$tglnow."', 
	d2='".$ssid."', 
	d3='0', 
	d4='1', 
	d5='".$date1[$i]."', 
	d6='".$date2[$i]."', 
	d7='".$time1[$i]."', 
	d8='".$time2[$i]."', 
	d9='".$time3[$i]."', 
	d10='".$salary[$i]."', 
	d11='".$totalsalary."',
	d12='".strtoupper($name[$i])."',
	d13='".$totalhours."',
	d14='".strtoupper($row1[5])."',
	d15='',
	d16='".$deptnm1.$codedate2."',
	d17='".$rmkDW[$i]."';");


	//******cek nota***//
	$result5 = mysqli_query($con,"SELECT * FROM hrd.form_dw order by d0 desc limit 1;");
	$row5= mysqli_fetch_row($result5);
	$nota=$row5[0];
	//*************set log*******************//
	$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='input order', d4='".$nota."';");

				}


		}

sleep(0.3);

}


//print $database;

mysqli_close($con);


	print "
	<script language='javascript'>
	setTimeout(function(){
		window.close();
	}, 2500);
	</script>";


?>