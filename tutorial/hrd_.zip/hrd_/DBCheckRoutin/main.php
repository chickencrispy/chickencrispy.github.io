<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include '../mysql-connector.php';

print"

<HTML>
<HEAD>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9' crossorigin='anonymous'>
<style>
	table, tr, td{border:solid black 1px;  border-collapse:collapse; margin:auto; text-align:center;padding:2px;}
</style>
</HEAD>
<BODY>
    <br>
    <br>
    <div id='show' align='center'></div>

    <div id='show01' align='center'>
		<p><b>CheckingDBonline</b></p>
		<p><b>$tglnow</b></p>
	<table>
		<tr style='font-weight:bold;'>
			<td>No</td>
			<td>ID</td>
			<td>Time Online Yellow/ Off RED</td>
			<td>Pass Time</td>
		</tr>
";

$result = mysqli_query($con, "SELECT d2,d1,d6 FROM `log`.hrd_dw_pass where d8 not like '0';");

$act=0;
$n=0;
while($row = mysqli_fetch_row($result)){
$n++;

print"
		<tr>
			<td style='font-weight:bold;'>$n</td>
			<td>$row[0]</td>
";

	if($tglnow<=$row[2]){//print $tglnow." = ".$row[2]."<br>";
print"
			<td style='background-color:yellow;'>$row[1]</td>
";
			}else{$act=1;
print"
			<td style=background-color:red;>$row[1]</td>
";
				}

print"
			<td>$row[2]</td>
		</tr>
";
}


print"

	</table>	
    </div>


    <div align='center'>
        <p>
            by <a href='https://planetholidayhotel.com'><i>IT Service </i></a>
        </p>
    </div>
</BODY>
</pre>
</HTML>

";


if($act==1){

$vid=substr(sha1(mt_rand()),17,20);

//-----------CEK DATA md5---------//
$result1 = mysqli_query($con,"update `log`.hrd_dw_pass set d3='".$vid."' where d2 like'".$row[0]."' ;");
}


?>