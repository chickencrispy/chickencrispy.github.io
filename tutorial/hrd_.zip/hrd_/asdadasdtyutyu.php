<?php

//---mysql connect---//
include 'mysql-connector.php';

include 'vercfg.php';

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];

//print $main."<br>";
include'ver_page.php';

include "../schedule/hidden.php";

?>