<?php


//---mysql connect---//
include 'mysql-connector.php';

//*************GET NAME************************//
/*$n=1;
$result01 = mysqli_query($con, "SELECT * FROM hrd.employee_profiles;");
$data = array();
while ($row01 = mysqli_fetch_row($result01)){

$data[]=$row01[2];

//print $row01[2]."<br>";
$n++;
}


$jsn = json_encode($data);

echo $jsn;*/

$sql = "SELECT d2 FROM hrd.employee_profiles;";
if($result = $con->query($sql)){
  $data = array();
  while($row = $result->fetch_assoc()){
    $data[] = $row;
  }

  $json = json_encode($data);
  echo $json;
  $result->free();
}

?>