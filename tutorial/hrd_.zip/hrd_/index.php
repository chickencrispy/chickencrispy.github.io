<?php

//---mysql connect---//
include 'mysql-connector.php';

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');



print"

<html>
<head><meta name='viewport' content='width=device-width, initial-scale=1.0'>
<title>Planet Holiday Hotel & Residences</title>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css' rel='stylesheet' integrity='sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3' crossorigin='anonymous'>
</head>


<style>
.center {  position:relative; margin: auto;  width: 80%;  border: 0px solid green;  padding: 0px;}
.center1 {  position:relative; background-color:yellow; margin:auto;  width: 40%; height:0px;  border: 0px solid blue;  padding: 0px; top:0px;}

div {width:100%; height:20%; background-color:transparent; position:relative; top:25%; right:0px;}
table { width:100%; margin:0px 0px 0px 0px; padding:0px 0px 0px 0px;  border-style:solid; border-width:0px; border-spacing:0px; font-family:verdana; font-size:13px; border-collapse:collapse; }
body { margin:0px; padding:0px; border-style:solid; ; border-width:0px; border-spacing:0px; }
tr { margin:0px; padding:0px; border-style:solid;  border-width:0px; border-spacing:0px;}
td { border-color:#d6d6c2; margin:0px; padding:10px 0 0 0; border-style:solid;  border-width:0px; border-spacing:0px; text-align:center; width:90px; color:#6b6b47;}

.input {margin:0px; padding:0px; border-style:solid;  border-width:1px; border-spacing:0px; background-color:#d6d6c2; height:30px;}



</style>






<body >
<div class=center1>
<table>
";


print"
	<tr>
		<td style='text-align:left;'><b><i><span style='color:red;'>&nbsp</span></i></b><ul>
";

$result = mysqli_query($con, "SELECT *, count(d16) as d18 FROM hrd.form_dw where d3 like '0' and d4 like '1' group by d14;");

$n='0';
while($row = mysqli_fetch_row($result)){
$n++;

print"
				<li>Date of <i>".date_format((date_create($row[1])),'d F Y' ).",</i> Dept. $row[14] requestion`s under surveilance</li>
";

}



print"
					</ul></td>
	</tr>
";


print"

</table>
</div>



<div class=center>
<table>
	<tr>
		<td style='text-align:center;'><img src='logo.png'></td>
	</tr>
	<tr>
		<td><b><i>PASSCODE</i></b></td>
	</tr>
	<tr>
<form action='verpass.php' method='post' target='_self'>
		<td><input type='password' name='sid' id='sid' required='required' autofocus></td>
	</tr>
	<tr>
		<td style='text-align:center;'><input type='submit' VALUE='NEXT'></td>
	</tr>
	<tr>
		<td style='text-align:center;'><a href='cg_pass.php' target='_self'><b><i><u>Change_Pass</u></i></b></a></td>
	</tr>

</form>
</table>
</div>

</body>

</html>
";

print"
<script language='javascript'>
setTimeout(function(){
   window.location.reload(1);
}, 150000);
</script>
";

mysqli_close($con);

?>