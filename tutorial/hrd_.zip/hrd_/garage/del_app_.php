<?php


print'<b><i>loading system....</i></b><br>';

//---mysql connect---//
include 'mysql-connector.php';

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');



$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];

print $ssid.'<br>';
print $vid.'<br>';

if(!empty($_REQUEST['page'])){$rejected=$_REQUEST['page'];
print $rejected.'<br>';

$page1=$_REQUEST['page1'];
print $page1.'<br>';



$rejected1=$_REQUEST['rejected1'];
print $rejected1.'<br>';

//*************reject***********//
$n='0';
for($i=0;$i<=50;$i++){
if(!empty($_REQUEST['rejected'.$i])){$n++; $rejectedn[$n]=$_REQUEST['rejected'.$i];};
}
print $n.'<br>';







for($a=1;$a<=$n;$a++){print 'reject'.$a.'= '.$rejectedn[$a].'<br>';}


if ($n=='0'){
	print 'satuan'.'<br>';
		$result1 = mysqli_query($con, "update hrd.form_dw set d4='0' where d0 like '".$rejected."'");
}else{


	print 'banyak'.'<br>';
		for($a=1;$a<=$n;$a++){
	print $rejectedn[$a].'<br>';
			$result1 = mysqli_query($con, "update hrd.form_dw set d4='0' where d0 like '".$rejectedn[$a]."'");
				}
	}

	print "
	<script language='javascript'>
	setTimeout(function(){
		//window.close();
	}, 1000);
	</script>";

}

mysqli_close($con);
?>