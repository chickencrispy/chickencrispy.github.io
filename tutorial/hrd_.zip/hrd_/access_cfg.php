<?php

$user='X|A|B|C|E';
$admin='X|A|B|C|D|E';
$super='X|A|B|C|D|E|F|G';

if($attr=='user'){$attr=$user;}
if($attr=='admin'){$attr=$admin;}
if($attr=='super'){$attr=$super;}

?>