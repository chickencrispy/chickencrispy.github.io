<?php


//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include 'mysql-connector.php';


$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
if(isset($_REQUEST['akses2'])){$akses2=$_REQUEST['akses2'];}else{$akses2='null';}
if(isset($_REQUEST['passcode'])){$passcode=$_REQUEST['passcode'];}else{$passcode='null';}
if(isset($_REQUEST['attr'])){$attr=$_REQUEST['attr'];}else{$attr='null';}



//print 'ssid= '.$ssid.'<br>';
//print 'vid= '.$vid.'<br>';
//print 'akses2= '.$akses2.'<br>';
//print 'passcode= '.$passcode.'<br>';
//print 'attr= '.$attr.'<br>';



if(($akses2=='null')&&($passcode=='')){
	print "<script>window.alert('no user updated');window.history.back();</script>";
}else{

include 'access_cfg.php';
//print $attr;

$passcode=md5($passcode);

//**********set update***************//
$result = mysqli_query($con, "update `log`.hrd_dw_pass set d7='".$attr."', d4='".$passcode."', d8='1' where d0 like '".$akses2."';");

	//**********CEk account***************//
	$result1 = mysqli_query($con, "SELECT * FROM `log`.hrd_dw_pass where d0 like '".$akses2."';");
	$row1 = mysqli_fetch_row($result1);
	//*************set log*******************//
	$result2 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='update account of', d4='".$row1[2]."';");

	print "<script>window.alert('user was updated');window.close();</script>";
}


?>