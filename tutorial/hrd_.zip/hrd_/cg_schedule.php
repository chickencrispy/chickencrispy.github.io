<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include 'mysql-connector.php';

$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];
$page=$_REQUEST['page'];

$cgdate=$_REQUEST['cgdate'];
if(isset($_REQUEST['timesch'])){$timesch=$_REQUEST['timesch'];}else{$timesch='null';}
$time1=$_REQUEST['time1'];if($time1==''){$time1='00:00';}
$time2=$_REQUEST['time2'];if($time2==''){$time2='00:00';}
if(isset($_REQUEST['chgsalary'])){$chgsalary=$_REQUEST['chgsalary'];}else{$chgsalary='20000';}
if(isset($_REQUEST['set'])){$set=$_REQUEST['set'];}else{$set='0';}

//print 'ssid= '.$ssid.'<br>';
//print 'vid= '.$vid.'<br>';
//print 'page= '.$page.'<br>';

//print 'cgdate= '.$cgdate.'<br>';
//print 'timesch= '.$timesch.'<br>';
//print 'time1= '.$time1.'<br>';
//print 'time2= '.$time2.'<br>';
//print 'chgsalary= '.$chgsalary.'<br>';
//print $set.'<br>';





//*******GET NAME DW***************//
$result1= mysqli_query($con, "SELECT * FROM hrd.form_dw where d0 like'".$page."';");
$row1 = mysqli_fetch_row($result1);

//print $row1[10].'<br>';

$tt1=$time1.':00';
$tt2=$time2.':00';


$totalsalary='0';
$totaltime='0';

if($set=='1'){

if (($time1!='00:00')&&($cgdate!='')){
	$time1 = new DateTime($time1);
	$time2 = new DateTime($time2);
	$interval = $time1->diff($time2);
	$totaltime=$interval->format('%h');
$totalsalary=$totaltime*$chgsalary;
				}
if($time1=='00:00'){
	$totaltime='8';
	$totalsalary=$chgsalary;
}

$result= mysqli_query($con, "update hrd.form_dw set d5='".$cgdate."', d7='".$tt1."', d8='".$tt2."', d9='".$timesch."', d10='".$chgsalary."', d11='".$totalsalary."', d13='".$totaltime." hours' where d0 like '".$page."';");

	//*************set log*******************//
	$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='change schedule order', d4='".$page."';");
sleep(0.8);

print"
<script>window.location.assign('cne_app.php?ssid=$ssid&vid=$vid&date1=&input1=&name=&dept=');</script>
";

}

//print 'totaltime= '.$totaltime.'<br>';
//print 'totalsalary= '.$totalsalary.'<br>';






print"
<html>
<style>
	div{border:solid blue 0px; position:relative; top:0px; right:0px; margin:auto; width:1000px; height:1000px;}
	body{border:solid green 0px; padding:10px 0 0 0;}
	table{border:solid red 0px; font-family:calibri; font-size:11pt; width:650px; border-collapse:collapse}

	.td1{border:solid grey 1px; text-align:center; }
	td{border:solid grey 0px;}
	input{border:1px solid grey; background-color:#e8e5dc; font-weight:bold;}
</style>

<script>
	function chg(){
	document.getElementById('time1').readOnly =true;
	document.getElementById('time2').readOnly =true;
	}
	function chg1(){
	document.getElementById('timesch').disabled =true;
	document.getElementById('chgsalary').disabled =true;
	}
</script>
<body>

<div>

<table>
	<tr><td colspan=7 align=center><b><u>Information of DW</u></b></td></tr>
	<tr><td>&nbsp</td></tr>

	<tr style='font-weight:bold;'> 
		<td class=td1>Date</td>
		<td class=td1>Time schedule</td>
		<td class=td1>Name of DW</td>
		<td class=td1>SALARY</td>
		<td class=td1>Total hours</td>
		<td class=td1>Total</td>
		<td class=td1>Remark</td>
	</tr>

	<tr>
		<td  class=td1>".date_format((date_create($row1[5])),'d F Y' )."</td>
";
	if($row1[9]!='null'){
print"
		<td  class=td1>$row1[9]</td>
";
			}else{
print"
		<td  class=td1>$row1[7] - $row1[8]</td>
";
			}

print"
		<td  class=td1>".strtoupper($row1[12])."</td>
		<td  class=td1>Rp ".number_format($row1[10],0,',','.').",-</td>
		<td  class=td1>$row1[13]</td>
		<td  class=td1>Rp ".number_format($row1[11],0,',','.').",-</td>
		<td  class=td1>".ucfirst(strtolower($row1[17]))."</td>
	</tr>
	<tr><td>&nbsp</td></tr>
	<tr>
	
			<td colspan=2><b><i>Note :</i></b><ul>
				<li>A 	: 15:00-23:00</li>
				<li>A2 	: 16:00-24:00</li>
				<li>A4 	: 18:00-02:00</li>
				<li>M 	: 07:00-15:00</li>
				<li>D1 	: 09:00-17:00</li>
				<li>D2 	: 09:00-18:00</li>
				<li>SN 	: 09:00-14:00</li>

			</ul></td>
			<td colspan=2>&nbsp<ul>
				<li>NS 	: 08:00-16:00</li>
				<li>N 	: 23:00-07:00</li>
				<li>N2 	: 23:00-02:00</li>
				<li>D3 	: 11:00-07:00</li>
				<li>D4 	: 12:00-20:00</li>
				<li>D5 	: 13:00-21:00</li>
			</ul></td>
			<td colspan=2>&nbsp<ul>
				<li>D6 	: 14:00-22:00</li>
				<li>M1 	: 06:00-14:00</li>
				<li>M2 	: 07:00-15:00</li>
				<li>EM 	: 04:00-12:00</li>
			</ul></td>
	</tr>
</table>

<table>
<form action='cg_schedule.php' method='get' target='_self' >

<input type='hidden' value='$ssid' name='ssid'>
<input type='hidden' value='$vid' name='vid'>
<input type='hidden' value='$page' name='page'>
<input type='hidden' value='1' name='set'>

	<tr><td><b><i>Name of DW</b></td></tr>
	<tr>
		<td><input type='text' value='".$row1[12]."' readonly></td>
	</tr>
	<tr><td>&nbsp</td></tr>
	<tr><td><b><i>Date of DW</b></td></tr>
	<tr>
		<td><input type='date' name='cgdate' id='cgdate'  required autofocus></td>
	</tr>
	<tr><td>&nbsp</td></tr>
	<tr><td><b><i>Time Schedule DW</b></td></tr>
	<tr>
		<td><select name='timesch' id='timesch' onclick='chg();'>
		<option value='null'>-</option>
		<option value='A'>A</option>
		<option value='A2'>A2</option>
		<option value='A4'>A4</option>
		<option value='EM'>EM</option>
		<option value='M'>M</option>
		<option value='M1'>M1</option>
		<option value='M2'>M2</option>
		<option value='D1'>D1</option>
		<option value='D2'>D2</option>
		<option value='D3'>D3</option>
		<option value='D4'>D4</option>
		<option value='D5'>D5</option>
		<option value='D6'>D6</option>
		<option value='SN'>SN</option>
		<option value='N'>N</option>
		<option value='N2'>N2</option>
		<option value='NS'>NS</option>
		</select>	</td>
	</tr>
	<tr><td><b><i>Per Hours</b></td></tr>
	<tr>
		<td>
			<input type='time' name='time1' id='time1' onclick='chg1();' required> s/d <input type='time' name='time2' id='time2' required>

		</td>
		<td><b><i>Note</i> :</b> [12:00 AM = malam]  [12:00PM = siang]</td>
	</tr>
	<tr><td>&nbsp</td></tr>
	<tr><td><b><i>Salary</b></td></tr>
	<tr>
		<td><select name='chgsalary' id='chgsalary'>
			<option value='$row1[10]' selected>Rp. $row1[10]</option>
			<option value='165000'>Rp. 165.000</option>
			<option value='150000'>Rp. 150.000</option>
			<option value='125000'>Rp. 125.000</option>
			<option value='100000'>Rp. 100.000</option>
			<option value='60000'>Rp. 60.000</option>
			<option value='50000'>Rp. 50.000</option>
		</select></td>
	</tr>
	<tr><td>&nbsp</td></tr>
	<tr>
		<td><input type='submit' value='SAVE'></td>
	</tr>
</form>
</table>
</div>

</body>
</html>
";






//if($cgname!=''){
	//$result= mysqli_query($con, "update hrd.form_dw set d12='".strtoupper($cgname)."' where d0 like '".$page."';");



//}


mysqli_close($con);


?>