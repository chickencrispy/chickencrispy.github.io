<?php


//-----mysql----//
include 'mysql-connector.php';
//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date("Y-m-d H:i:s");
//print $tglnow."<br>";

if(!empty($_POST['sid'])){$sid=$_REQUEST['sid'];}else{ $sid='';}
//print $sid.'<br>';



$sidmd5=md5($sid);
//print $sidmd5."<br>";
//-----------CEK DATA---------//
$result = mysqli_query($con,"SELECT * FROM `log`.hrd_dw_pass where d4 like '".$sidmd5."';");
$row = mysqli_fetch_row($result);
//print $row[2].'<br>';


$result1 = mysqli_query($con,"SELECT hrd_dw_pass.d2, employee_position.d2, chart_organize.d1, chart_organize.d0, hrd_dw_pass.d7 FROM `log`.hrd_dw_pass, hrd.employee_position, hrd.chart_organize where hrd_dw_pass.d2 like '".$row[2]."' and employee_position.d3 like hrd_dw_pass.d2 and chart_organize.d0 like employee_position.d1;");
$row1 = mysqli_fetch_row($result1);
//print $row1[2]."<br>";

$begin=strpbrk($row1[4], 'Z');
//print $begin."<br>";


if (($sidmd5==$row[4])&&($row1[3]=='35')or($row1[3]=='34')or($begin!='')){
//print 'ok<br>';

$vid=substr(sha1(mt_rand()),17,20);

//print $vid;


//***********set pass timelogin**************//
$dateN=date_create(date('Y-m-d H:i:s'));
//print $dateN->format("H:i:s").'<br>';
date_add($dateN,date_interval_create_from_date_string("1 Hours"));
$dateN1=date_format($dateN,'Y-m-d H:i:s');
//print $dateN1.'<br>';


$result2 = mysqli_query($con,"update `log`.hrd_dw_pass set d1='".$tglnow."', d6='".$dateN1."' where d2 like '".$row[2]."';");
$result3 = mysqli_query($con,"update`log`.hrd_dw_pass set d3='".$vid."' where d2 like '".$row[2]."';");


//*************set log*******************//
$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$row[2]."', d3='login';");



print"
<script>
window.location.assign('appr_app.php?ssid=$row[2]&vid=$vid&input1=&dept=');
</script>
";

}else{

print"
<script>
window.history.back();
</script>
";



}


?>