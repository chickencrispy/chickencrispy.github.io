<?php



$X='main';
$A='report_list_app';
$B='appr_list_app';
$C='report_app';
$D='cne_app';
$E='log_app';
$F='Account_app';
$Z='appr_app';
$G='schedule';
$H='hidden_app2';




$verid=$_REQUEST['ssid'];
//print 'verid=  '.$verid.'<br>';

//******CEK ACCESS********//
$result0 = mysqli_query($con, "SELECT * FROM `log`.hrd_dw_pass where d2 like '".$verid."';");
$row0 = mysqli_fetch_row($result0);

//print $row0[7].'<br>';

$pathname = substr(basename($_SERVER['PHP_SELF']),0,-4);
//print $pathname.'<br>';

$cfu=explode('|',$row0[7]);
$n=count(explode('|',$row0[7]));
//print $cfu[6].'<br>';
//print $n.'<br>';


for($i=0;$i<=($n-1);$i++){
if ($cfu[$i]=='X'){$cfu[$i]=$X; }
if ($cfu[$i]=='A'){$cfu[$i]=$A; }
if ($cfu[$i]=='B'){$cfu[$i]=$B; }
if ($cfu[$i]=='C'){$cfu[$i]=$C; }
if ($cfu[$i]=='D'){$cfu[$i]=$D; }
if ($cfu[$i]=='E'){$cfu[$i]=$E; }
if ($cfu[$i]=='F'){$cfu[$i]=$F; }
if ($cfu[$i]=='G'){$cfu[$i]=$G; }
if ($cfu[$i]=='H'){$cfu[$i]=$H; }
}
//print '<br>';

$akses='0';
for($i=0;$i<=($n-1);$i++){
//print $cfu[$i];

	if($cfu[$i]==$pathname){
		$akses='1'; 
		//print' sama';
			}else{
		//print ' tidak-sama ';
				}
//print'<br>';
}

//print'<br>';
//print $akses.'<br>';
if ($akses=='0'){
		print'
		<script>
			window.alert(`Disable Access`);
			window.location.assign("index.php");
		</script>
		';

	}
?>