<?php



//---mysql connect---//
include 'mysql-connector.php';

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

$ssid=$_REQUEST['ssid'];

//*************getstatusGM/asstGM****************//
$result1 = mysqli_query($con, "SELECT hrd_dw_pass.d2, employee_position.d2, chart_organize.d1, chart_organize.d0 FROM `log`.hrd_dw_pass, hrd.employee_position, hrd.chart_organize where hrd_dw_pass.d2 like '".$ssid."' and employee_position.d3 like hrd_dw_pass.d2 and chart_organize.d0 like employee_position.d1;");
$row1 = mysqli_fetch_row($result1);
//print $row1[3].'<br>';

if($row1[3]=='35'){$status='B';}
if($row1[3]=='34'){$status='A';}
//print $status.'<br>';


$input1=$_REQUEST['input1'];
$ssid=$_REQUEST['ssid'];
$vid=$_REQUEST['vid'];

//$fpapproved1=$_REQUEST['fpapproved1'];

if(!empty($_REQUEST['fpapproved1'])){$fpapproved[1]=$_REQUEST['fpapproved1'];}else{$fpapproved[1]='null';};
if(!empty($_REQUEST['fpapproved2'])){$fpapproved[2]=$_REQUEST['fpapproved2'];}else{$fpapproved[2]='null';};
if(!empty($_REQUEST['fpapproved3'])){$fpapproved[3]=$_REQUEST['fpapproved3'];}else{$fpapproved[3]='null';};
if(!empty($_REQUEST['fpapproved4'])){$fpapproved[4]=$_REQUEST['fpapproved4'];}else{$fpapproved[4]='null';};
if(!empty($_REQUEST['fpapproved5'])){$fpapproved[5]=$_REQUEST['fpapproved5'];}else{$fpapproved[5]='null';};
if(!empty($_REQUEST['fpapproved6'])){$fpapproved[6]=$_REQUEST['fpapproved6'];}else{$fpapproved[6]='null';};

if(!empty($_REQUEST['fprejected1'])){$fprejected[1]=$_REQUEST['fprejected1'];}else{$fprejected[1]='null';};
if(!empty($_REQUEST['fprejected2'])){$fprejected[2]=$_REQUEST['fprejected2'];}else{$fprejected[2]='null';};
if(!empty($_REQUEST['fprejected3'])){$fprejected[3]=$_REQUEST['fprejected3'];}else{$fprejected[3]='null';};
if(!empty($_REQUEST['fprejected4'])){$fprejected[4]=$_REQUEST['fprejected4'];}else{$fprejected[4]='null';};
if(!empty($_REQUEST['fprejected5'])){$fprejected[5]=$_REQUEST['fprejected5'];}else{$fprejected[5]='null';};
if(!empty($_REQUEST['fprejected6'])){$fprejected[6]=$_REQUEST['fprejected6'];}else{$fprejected[6]='null';};


//print $input1.'<br>';
//print 'approve1= '.$fpapproved[1].'<br>';
//print 'approve2= '.$fpapproved[2].'<br>';
//print 'approve3= '.$fpapproved[3].'<br>';
//print 'approve4= '.$fpapproved[4].'<br>';
//print 'approve5= '.$fpapproved[5].'<br>';
//print 'approve6= '.$fpapproved[6].'<br>';

//print 'reject1= '.$fprejected[1].'<br>';
//print 'reject2= '.$fprejected[2].'<br>';
//print 'reject3= '.$fprejected[3].'<br>';
//print 'reject4= '.$fprejected[4].'<br>';
//print 'reject5= '.$fprejected[5].'<br>';
//print 'reject6= '.$fprejected[6].'<br>';

$database='1';

$null='0';
//*********cekisisama****//
for($x=1;$x<=6;$x++){
	if(($fpapproved[$x] != 'null')&&($fprejected[$x] != 'null')){$database='0';}
	if($fpapproved[$x] == 'null'){$null=$null+1;}
	if($fprejected[$x] == 'null'){$null=$null+1;}
		}
//print $null.'<br>';
	if ($null=='12'){$database='0';}

//print $database.'<br>';

	if($database!='0'){
print'<b><i>Loading System.......</i></b>';

	for($i=1;$i<=6;$i++){
	
		if($fpapproved[$i] != 'null'){

		//**********CEK NOTA********************//
		$result5 = mysqli_query($con,"SELECT * FROM hrd.form_dw where d3 like '0' and d4 like '1' and d14 like '".$fpapproved[$i]."' and d1 like '".$input1."' order by d0 asc;");
		while($row5 = mysqli_fetch_row($result5)){
			//*************set log*******************//
			$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='approve order', d4='".$row5[0]."';");
		sleep(0.5);					
						}

			//print 'approve'.$i.'<br>';
		$result = mysqli_query($con, "update hrd.form_dw set d3='".$ssid."', d15= '".$status."' where d14 like '".$fpapproved[$i]."' and d1 like '".$input1."' and d3 like '0' and d4 like '1' ;");

					}
	} 


	for($n=1;$n<=6;$n++){
	
		if($fprejected[$n] != 'null'){

		//**********CEK NOTA********************//
		$result5 = mysqli_query($con,"SELECT * FROM hrd.form_dw where d3 like '0' and d4 like '1' and d14 like '".$fprejected[$n]."' and d1 like '".$input1."' order by d0 asc;");
		while($row5 = mysqli_fetch_row($result5)){
			//*************set log*******************//
			$result4 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$tglnow."', d2='".$ssid."', d3='reject order', d4='".$row5[0]."';");
		sleep(0.5);					
						}

			//print 'reject'.$n.'<br>';
		$result = mysqli_query($con, "update hrd.form_dw set d3='".$ssid."',d4='2', d15= '".$status."' where d14 like '".$fprejected[$n]."' and d1 like '".$input1."' and d3 like '0' and d4 like '1';");	
	
				}
	} 

	print"
	<script language='javascript'>
	setTimeout(function(){
		window.close();
	}, 2500);
	</script>";


		}else{
	print"
	<script language='javascript'>
	setTimeout(function(){
		window.alert('ceklist tidak boleh keduanya / kosong ');
		window.close();
	}, 500);
	</script>";
			}
?>