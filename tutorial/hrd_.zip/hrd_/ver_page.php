<?php

$result6 = mysqli_query($con, "SELECT * FROM `log`.hrd_dw_pass where d2 like '".$ssid."';");
$row6 = mysqli_fetch_row($result6);

if($vid!=$row6[3]){print"<script>window.alert('user expired vid not valid');window.location.assign('index.php');</script>";die();}
if($ssid==''){print"<script>window.alert('user expired ssid empty');window.location.assign('index.php');</script>";die();}
if($vid==''){print"<script>window.alert('user expired vid empty');window.location.assign('index.php');</script>";die();}


//*************CEK USER ONLINE TO OFFLINE***********//

$timelogin1=date('Y-m-d H:i:s');
$timelogin2=$row6[6];
//print $timelogin1.'<br>';
//print $timelogin2.'<br>';

if($timelogin1>=$timelogin2){
	$result7 = mysqli_query($con, "update `log`.hrd_dw_pass set d3='' where d2 like '".$ssid."';");
		//*************set log*******************//
		$result8 = mysqli_query($con,"insert into `log`.log_dw_app set d1='".$timelogin1."', d2='".$ssid."', d3='expired login';");	

		print"<script>window.alert('user expired');window.location.assign('./');</script>";
			}

if($timelogin1<$timelogin2){

//***********set pass timelogin**************//
$dateN=date_create(date('Y-m-d H:i:s'));
//print $dateN->format("H:i:s").'<br>';
date_add($dateN,date_interval_create_from_date_string("1 Hours"));
$dateN1=date_format($dateN,'Y-m-d H:i:s');
//print $dateN1.'<br>';

$result2 = mysqli_query($con,"update`log`.hrd_dw_pass set d1='".$timelogin1."', d6='".$dateN1."' where d2 like '".$ssid."';");
}


?>