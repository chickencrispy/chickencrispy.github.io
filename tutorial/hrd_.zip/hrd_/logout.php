<?php

//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");
$tglnow=date('Y-m-d H:i:s');

//---mysql connect---//
include 'mysql-connector.php';

$ssid=$_REQUEST['ssid'];
$vid=substr(sha1(mt_rand()),17,20);
//print $ssid;


	//-----------DELETE VID-----------//
		$result= mysqli_query($con, "update `log`.hrd_dw_pass set d3='".$vid."', d6='".$tglnow."' where d2 like '".$ssid."';");

print"
<script>window.location.assign('/hrd');</script>
";
?>