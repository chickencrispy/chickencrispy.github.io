<?php



//-----mysql----//
include 'mysqlv5-connector.php';



//-------------Tanggal&Tahun--------------------//
date_default_timezone_set("Asia/Jakarta");

$tglnow=date("Y-m-d H:i:s");

if(!empty($_POST['sid'])){$sid=$_REQUEST['sid'];}else{ $sid='';}
if(!empty($_POST['pass'])){$pass=$_REQUEST['pass'];}else{$pass='';}

if(!empty($_POST['recom'])){$recom=$_REQUEST['recom'];}else{ $recom='';}

/*
print $sid.'<br>';
print $pass.'<br>';
print $recom.'<br>';
*/

//-----------CEK DATA---------//
$result = mysqli_query($con,"SELECT * FROM `log`.mcis_pass where d0 like '1' and d2 like '".$recom."';");
$row = mysqli_fetch_row($result);
//print $row[2];

if(($sid!='')and($pass!='')and($recom==$row[2])){

	//-----------INPUT DATA-----------//
	$result3= mysqli_query($con, "insert into `log`.mcis_pass set d1='".$sid."', d2='".$pass."', d3='', d5='".$row[1]."';");
print "
<script>
	alert('passcode was created');
	window.location.assign('index.php');
</script>
";
}

if($recom!=$row[2]){

print"
<script>
	alert('invalid');
	window.location.assign('index.php');
</script>
";
}



print"

<html>
<title>Planet Holiday Hotel & Residences</title>



<style>
.center {  margin: auto;  width: 20%;  border: 0px solid green;  padding: 0px;}

div {width:100%; height:20%; background-color:transparent; position:relative; top:25%; right:0px;}
table { width:100%; margin:0px 0px 0px 0px; padding:0px 0px 0px 0px;  border-style:solid; border-width:0px; border-spacing:0px; font-family:verdana; font-size:13px; border-collapse:collapse; }
body { margin:0px; padding:0px; border-style:solid; ; border-width:0px; border-spacing:0px; }
tr { margin:0px; padding:0px; border-style:solid;  border-width:0px; border-spacing:0px;}
td { border-color:#d6d6c2; margin:0px; padding:10px 0 0 0; border-style:solid;  border-width:0px; border-spacing:0px; text-align:center; width:90px; color:#6b6b47;}

.input {margin:0px; padding:0px; border-style:solid;  border-width:1px; border-spacing:0px; background-color:#d6d6c2;}
</style>

<body>

<div class=center>
<table>
	<tr><td style='text-align:center;'><img src='logo.png'></td></tr>
<form action='mcis-cr-pass.php' method='post' target='_self'>
	<tr><td><b><i>USERNAME</i></b>&nbsp<input type='text' name='sid' id='sid' required='required' autofocus></td></tr>
	<tr><td><b><i>PASSCODE</i></b>&nbsp<input type='password' name='pass' id='pass' required='required' autofocus></td></tr>
	<tr><td><b><i>ReCOMMANDED</i></b>&nbsp<input type='password' name='recom' id='pass' required='recom' autofocus></td></tr>
	<tr>
		<td style='text-align:center;'><input type='submit' VALUE='CREATE'></td>
	</tr>
</form>
</table>
</div>

</body>

</html>




";
?>